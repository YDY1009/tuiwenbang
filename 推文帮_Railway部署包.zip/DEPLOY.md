# 把推文帮交给别人打开

## 为什么不能直接发文件夹

`http://127.0.0.1:4173` 只在你自己的电脑上有效。把文件夹发给别人，对方双击 `index.html` 也打不开，因为登录、生成、搜索都需要 Node 服务端和 DeepSeek 密钥。

## 方案一：部署成公网地址（推荐，长期可打开）

### Render

1. 把项目推到 GitHub（不要提交 `server/data/users.json`，里面是账号密码哈希）。
2. 在 Render 新建 **Web Service**，连接这个仓库。
3. 设置：
   - Runtime: Node
   - Build Command: `npm install`
   - Start Command: `npm start`
   - 环境变量：`DEEPSEEK_API_KEY=你的密钥`
   - 环境变量：`HOST=0.0.0.0`
4. 部署完成后 Render 会给一个 `https://xxxx.onrender.com` 地址，把这个地址发到邮件里即可。

Render 免费实例长时间没人访问会休眠，第一次打开可能要等 30–60 秒；要做到“随时秒开”，选 Render Starter 或 Railway，不要用免费休眠实例。

免费实例的文件系统是临时的，重启后账号可能需要重新注册；要保留账号，给 `server/data` 挂一个持久磁盘，或改用 Railway 的 Volume。

### Railway（推荐，服务可以一直在线）

1. 解压 `推文帮_Railway部署包.zip`，把里面的文件上传到一个新的 GitHub 仓库。
2. Railway 新建 Project，选择 **Deploy from GitHub repo**，选中这个仓库。
3. Railway 会自动识别根目录的 `Dockerfile`；如果没有识别，手动把 Dockerfile Path 设为 `Dockerfile`。
4. 在 Variables 里添加：
   - `DEEPSEEK_API_KEY`：你的密钥
   - `HOST`：`0.0.0.0`
   - `PORT`：`4173`
   - `DEEPSEEK_MODEL`：`deepseek-chat`
5. 给服务添加 Volume，Mount Path 填：
   `/app/server/data`
   这样账号不会随重启丢失。
6. Settings → Networking → Generate Domain；如果要求填端口，填 `4173`。
7. 打开 `https://你的域名/api/health`，看到 `"ok": true` 就部署成功。

Railway 需要付费的 Hobby 计划才能长期在线；免费试用额度用完后服务可能停止。国内访问 `*.up.railway.app` 有时不稳定，如果评审打不开，优先考虑国内云服务器或绑定自定义域名。

## 方案二：今天就要交，用临时公网链接

在运行服务的电脑上安装 Cloudflare Tunnel：

```bash
brew install cloudflared
cloudflared tunnel --url http://127.0.0.1:4173
```

终端会给出一个 `https://xxxx.trycloudflare.com` 地址。把地址发邮件，对方就能打开。

注意：这个地址依赖你的电脑、终端和隧道一直运行；电脑休眠或关闭终端，链接就失效。适合今天临时给对方看，不适合长期提交。

## 方案三：同一个办公室 / 同一个 Wi-Fi

把服务监听到局域网：

```bash
HOST=0.0.0.0 node server/server.js
```

查你的局域网 IP，例如 `192.168.1.23`，让对方访问：

```text
http://192.168.1.23:4173
```

只适合同一个网络，外网打不开。

## 邮件里怎么写

> 推文帮访问地址：https://你的域名
>
> 首次打开请点“创建一个”，自己设置账号和密码。登录后按“开始写”进入新建推文。
>
> 生成需要服务端调用模型，第一次打开可能需要等几十秒。

不要把 `DEEPSEEK_API_KEY` 写进邮件或前端代码；它只放在部署平台的环境变量里。

## 长期在线的最低要求

- 一台不会休眠的公网服务器（Railway / Render Starter / 云服务器）
- 固定域名或公网地址
- 环境变量 `DEEPSEEK_API_KEY` 配在服务器上
- `server/data` 挂持久磁盘，账号才不会随重启丢失

如果使用云服务器：

```bash
npm install
HOST=0.0.0.0 PORT=80 npm start
```

建议用 Nginx 反向代理并配置 HTTPS；不要把 4173 端口直接暴露给公网。
