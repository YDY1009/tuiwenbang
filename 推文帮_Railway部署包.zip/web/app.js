/* 推文帮 · app
   Vanilla JS, hash routing, localStorage. No build step. */

(() => {
  "use strict";

  const STORE_KEY = "tuibenbang:v1";
  const DATA_VERSION = 7;
  const app = document.getElementById("app");
  const toastEl = document.getElementById("toast");
  const overlayEl = document.getElementById("overlay");

  const icon = (name, cls = "") => {
    const paths = {
      home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h5v-6h4v6h5V9.5"/>',
      pen: '<path d="M12 20h9"/><path d="M16.6 3.4a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
      users: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.2 2.7-5.5 6-5.5s6 2.3 6 5.5"/><path d="M16 5.2a3.2 3.2 0 0 1 0 6.2"/><path d="M17.5 14.8c2.1.7 3.5 2.4 3.5 4.7"/>',
      check: '<circle cx="12" cy="12" r="8.5"/><path d="m8.5 12 2.3 2.3 4.8-5"/>',
      settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-1.7 1.7-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V20h-2.4v-.2a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1-1.7-1.7.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H4.4v-2.4h.2a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1 1.7-1.7.1.1a1.7 1.7 0 0 0 1.9.3 1.7 1.7 0 0 0 1-1.5V4h2.4v.2a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1 1.7 1.7-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.5 1h.2v2.4h-.2a1.7 1.7 0 0 0-1.5 1Z"/>',
      sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
      moon: '<path d="M20 14.3A8.5 8.5 0 1 1 9.7 4a6.8 6.8 0 0 0 10.3 10.3Z"/>',
      arrowRight: '<path d="M4 12h15"/><path d="m13 6 6 6-6 6"/>',
      arrowLeft: '<path d="M20 12H5"/><path d="m11 18-6-6 6-6"/>',
      plus: '<path d="M12 5v14M5 12h14"/>',
      spark: '<path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/>',
      clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
      chevron: '<path d="m6 9 6 6 6-6"/>',
      close: '<path d="m6 6 12 12M18 6 6 18"/>',
      file: '<path d="M6 3h8l4 4v14H6Z"/><path d="M14 3v4h4"/>',
      download: '<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M4 20h16"/>',
      alert: '<path d="M12 3 2.8 20h18.4L12 3Z"/><path d="M12 9v5"/><path d="M12 17.5v.1"/>',
      book: '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v18H6.5A2.5 2.5 0 0 0 4 22V4.5Z"/><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>',
      refresh: '<path d="M20 11a8 8 0 0 0-14.9-4L3 9"/><path d="M3 4v5h5"/><path d="M4 13a8 8 0 0 0 14.9 4L21 15"/><path d="M21 20v-5h-5"/>',
      external: '<path d="M14 3h7v7"/><path d="M10 14 21 3"/><path d="M21 14v7H3V3h7"/>',
      monitor: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>',
      image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9.5" r="1.5"/><path d="m21 15-4.5-4.5L6 21"/>',
      trash: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="m6 6 1 15h10l1-15"/><path d="M10 10v7M14 10v7"/>',
      more: '<circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/>',
      copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>'
    };
    return `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || ""}</svg>`;
  };

  const esc = (s) =>
    String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    }[c]));

  const deepClone = (obj) => JSON.parse(JSON.stringify(obj));
  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function loadState() {
    let saved = {};
    try { saved = JSON.parse(localStorage.getItem(STORE_KEY) || "{}"); } catch (e) { saved = {}; }
    const fresh = saved.version === DATA_VERSION;
    const seedPersonaVersion = SEED.personaSeedVersion || 1;
    const builtinIds = new Set(SEED.personas.map((p) => p.id));
    const savedPersonas = fresh && Array.isArray(saved.personas) ? saved.personas : [];
    const customPersonas = savedPersonas.filter((p) => p && p.id && !builtinIds.has(p.id));
    const personas = (!fresh || saved.personaSeedVersion !== seedPersonaVersion)
      ? [...deepClone(SEED.personas), ...customPersonas]
      : savedPersonas;
    const data = {
      version: DATA_VERSION,
      personaSeedVersion: seedPersonaVersion,
      theme: saved.theme || "system",
      personas,
      projects: (fresh && Array.isArray(saved.projects) ? saved.projects : deepClone(SEED.projects))
        .filter((p) => !p.sample)
        .map((p) => Object.assign({}, p, {
          updatedAt: normalizeTimestamp(p.updatedAt),
          createdAt: normalizeTimestamp(p.createdAt),
          ...(p.trashedAt ? { trashedAt: normalizeTimestamp(p.trashedAt) } : {})
        })),
      settings: Object.assign({}, deepClone(SEED.settings), fresh ? saved.settings || {} : {})
    };
    const seedBannedVersion = SEED.settings.bannedVersion || 2;
    if (!saved.settings || saved.settings.bannedVersion !== seedBannedVersion || !saved.settings.bannedExpanded) {
      data.settings.bannedPhrases = Array.from(new Set([
        ...(SEED.settings.bannedPhrases || []),
        ...(data.settings.bannedPhrases || [])
      ]));
      data.settings.bannedExpanded = true;
      data.settings.bannedVersion = seedBannedVersion;
    }
    return data;
  }

  let state = loadState();
  let authUser = null;
  let ui = {
    step: 1,
    draft: null,
    activeSection: 0,
    freshConsumed: false,
    lastPayload: null,
    genAbort: null,
    genTimer: null,
    lastSelection: null,
    titleData: null,
    outlineData: null,
    selectedTitleIndex: 0,
    selectedOutlineIndex: 0,
    authMode: "login",
    authType: "phone",
    personaStepSeeded: false,
    captcha: false,
    captchaProgress: 0
  };

  const AUDIENCES = [
    "普通读者", "科技爱好者", "消费者", "预算敏感", "学生", "家长",
    "职场人", "创业者", "管理者", "投资人", "股民 / 基民", "内容创作者",
    "开发者", "行业从业者", "自由职业者", "年轻女性", "年轻男性", "中老年",
    "情感困惑者", "文学读者", "影迷 / 剧迷", "自定义"
  ];

  const AI_HINTS = [
    "先说结论", "先给判断", "先给结论", "一句话总结", "综上所述", "总而言之",
    "归根结底", "说到底", "值得注意的是", "值得一提的是", "不难发现", "由此可见",
    "众所周知", "毋庸置疑", "不可否认", "首先", "其次", "再次", "最后",
    "随着", "在当今", "在这个", "让我们", "不仅", "而是", "真正的",
    "核心逻辑", "底层逻辑", "直击痛点", "重新定义", "直接封神", "炸裂",
    "干货满满", "保姆级", "一文读懂", "建议收藏", "划重点", "谁懂啊",
    "绝绝子", "狠狠", "姐妹们", "不要焦虑", "为你好", "你要相信"
  ];

  const PERSPECTIVE_HINTS = {
    auto: "按人设和文章形态判断：新闻 / 财经 / 文娱用第三人称，生活 / 情感 / 文学用第一人称。",
    first: "用“我”，但要求克制，不能每段都抒情。",
    second: "用“你 / 你们”直接对读者说话，适合建议、经验和互动型文章，但不要通篇说教。",
    third: "用“他 / 她 / 他们”，全文统一旁观，不突然写“我觉得”。",
    objective: "正文不出现“我 / 我们 / 你”，只写事实、场景和判断；最后一句评论区互动问题例外。"
  };

  const FORMATS = [
    { value: "深度长文", label: "深度长文", desc: "判断 + 拆解 + 结论" },
    { value: "经验分享", label: "经验分享", desc: "故事 + 方法 + 可执行" },
    { value: "人物故事", label: "人物故事", desc: "人物 + 细节 + 转折" },
    { value: "观点评论", label: "观点评论", desc: "现象 + 证据 + 判断" },
    { value: "问答", label: "问答", desc: "读者关心的问题" },
    { value: "自定义", label: "自定义", desc: "自己写形态" }
  ];

  function toneLabel(n) {
    return Number(n) <= 2 ? "偏理性" : Number(n) >= 4 ? "偏感性" : "平衡";
  }

  function saveState() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) { /* ignore */ }
  }

  function getPersona(id) {
    return state.personas.find((p) => p.id === id) || state.personas[0];
  }

  function getProject(id) {
    return state.projects.find((p) => p.id === id);
  }

  function activeProjects() {
    return state.projects.filter((p) => !p.trashed);
  }

  function trashedProjects() {
    return state.projects.filter((p) => p.trashed);
  }

  function currentReviewProject() {
    return activeProjects().find((p) => p.status === "review") || activeProjects()[0];
  }

  function statusLabel(s) {
    return { draft: "草稿", review: "待评审", published: "已发布" }[s] || s;
  }

  function nowISO() {
    return new Date().toISOString();
  }

  function parseTime(value) {
    if (value instanceof Date) return value;
    if (typeof value === "number") return new Date(value);
    if (!value || typeof value !== "string") return null;
    const today = new Date();
    let match = value.match(/^今天\s*(\d{1,2}):(\d{2})$/);
    if (match) {
      const d = new Date(today.getFullYear(), today.getMonth(), today.getDate(), Number(match[1]), Number(match[2]));
      return d;
    }
    match = value.match(/^昨天\s*(\d{1,2}):(\d{2})$/);
    if (match) {
      const d = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 1, Number(match[1]), Number(match[2]));
      return d;
    }
    if (value === "刚刚") return today;
    const d = new Date(value);
    return isNaN(d.getTime()) ? null : d;
  }

  function normalizeTimestamp(value) {
    if (!value || value === "刚刚") return nowISO();
    const d = parseTime(value);
    return d ? d.toISOString() : nowISO();
  }

  function formatTime(value) {
    const d = parseTime(value);
    if (!d) return value || "";
    const diff = Math.max(0, Date.now() - d.getTime());
    if (diff < 60 * 1000) return "刚刚";
    if (diff < 60 * 60 * 1000) return `${Math.floor(diff / 60000)} 分钟前`;
    if (diff < 24 * 60 * 60 * 1000) return `${Math.floor(diff / 3600000)} 小时前`;
    if (diff < 7 * 24 * 60 * 60 * 1000) return `${Math.floor(diff / 86400000)} 天前`;
    const now = new Date();
    const sameYear = d.getFullYear() === now.getFullYear();
    const md = `${d.getMonth() + 1}月${d.getDate()}日`;
    return sameYear ? md : `${d.getFullYear()}年${md}`;
  }

  function refreshTimes() {
    document.querySelectorAll("[data-time]").forEach((el) => {
      el.textContent = formatTime(el.dataset.time);
    });
  }

  function wordCount(project) {
    if (!project) return 0;
    const text = (project.title || "") +
      project.sections.map((s) => s.title + s.paragraphs.join("")).join("");
    return text.replace(/\s/g, "").length;
  }

  function metricsFor(project) {
    const base = (project.review && project.review.scores) || { persona: 0, style: 0, content: 0, human: 0 };
    const m = Object.assign({}, base);
    (project.review && project.review.issues ? project.review.issues : []).forEach((issue) => {
      if (!issue.resolved) return;
      Object.entries(issue.impact || {}).forEach(([k, v]) => {
        if (typeof m[k] === "number") m[k] = clamp(m[k] + v, 0, 100);
      });
    });
    return m;
  }

  function overallScore(m) {
    return Math.round(m.persona * 0.3 + m.style * 0.25 + m.content * 0.25 + m.human * 0.2);
  }

  function projectScore(project) {
    if (!project || !project.review || !project.review.scores) return null;
    return overallScore(metricsFor(project));
  }

  function unresolvedIssues(project) {
    if (!project.review || !project.review.issues) return [];
    return project.review.issues.filter((i) => !i.resolved);
  }

  function issueCounts(project) {
    const issues = (project.review && project.review.issues) || [];
    return {
      total: issues.length,
      open: issues.filter((i) => !i.resolved).length,
      high: issues.filter((i) => !i.resolved && i.severity === "high").length
    };
  }

  function themePref() { return state.theme || "system"; }
  function resolvedTheme() {
    if (themePref() === "system") {
      return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    }
    return themePref();
  }

  function applyTheme() {
    const resolved = resolvedTheme();
    document.documentElement.dataset.theme = resolved;
    document.documentElement.dataset.themePref = themePref();
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", resolved === "dark" ? "#0E100F" : "#F4F1EA");
  }

  function applyReading() {
    document.body.dataset.reading = (state.settings && state.settings.reading) || "normal";
    const scale = Number(state.settings && state.settings.fontScale) || 1.04;
    document.documentElement.style.setProperty("--ui-zoom", String(scale));
    document.body.style.zoom = String(scale);
  }

  function setTheme(pref, silent) {
    state.theme = pref;
    saveState();
    applyTheme();
    render(true);
    if (!silent) toast(pref === "system" ? "已跟随系统外观" : pref === "dark" ? "已切换到夜间模式" : "已切换到日间模式");
  }

  function toggleTheme() {
    const next = resolvedTheme() === "dark" ? "light" : "dark";
    setTheme(next, true);
  }

  function toast(message, ms = 2400) {
    toastEl.textContent = message;
    toastEl.classList.add("show");
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toastEl.classList.remove("show"), ms);
  }

  function download(name, text, type) {
    const blob = new Blob([text], { type: type || "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function personaAvatar(p, extra = "") {
    return `<span class="avatar ${extra}" style="color:${p.accent};border-color:${p.accent}33;background:${p.accent}0d">${esc(p.initial)}</span>`;
  }

  function scoreRing(score, size = 76) {
    const r = 32;
    const c = 2 * Math.PI * r;
    const offset = c * (1 - score / 100);
    return `<div class="score-ring" style="width:${size}px;height:${size}px">
      <svg viewBox="0 0 76 76" aria-hidden="true">
        <circle class="ring-bg" cx="38" cy="38" r="${r}"></circle>
        <circle class="ring-val" cx="38" cy="38" r="${r}" stroke-dasharray="${c.toFixed(1)}" stroke-dashoffset="${offset.toFixed(1)}"></circle>
      </svg>
      <b>${score}</b>
    </div>`;
  }

  function themeToggleHTML() {
    const dark = resolvedTheme() === "dark";
    return `${icon(dark ? "sun" : "moon")}<span class="theme-label">${dark ? "日间模式" : "夜间模式"}</span>`;
  }

  function todayLabel() {
    const d = new Date();
    const week = ["日", "一", "二", "三", "四", "五", "六"][d.getDay()];
    return `${d.getFullYear()} 年 ${d.getMonth() + 1} 月 ${d.getDate()} 日 · 星期${week}`;
  }

  function greeting() {
    const h = new Date().getHours();
    if (h < 6) return "夜深了";
    if (h < 11) return "早上好";
    if (h < 14) return "中午好";
    if (h < 18) return "下午好";
    return "晚上好";
  }

  function getRoute() {
    const raw = location.hash.replace(/^#\/?/, "");
    const [pathPart, queryPart] = raw.split("?");
    const parts = pathPart.split("/").filter(Boolean);
    return {
      name: parts[0] || "home",
      id: parts[1] || null,
      parts,
      params: new URLSearchParams(queryPart || "")
    };
  }

  function navItems() {
    return [
      { key: "home", label: "工作台", href: "#/", icon: "home" },
      { key: "personas", label: "人设库", href: "#/personas", icon: "users" }
    ];
  }

  function activeKey(route) {
    if (route.name === "home") return "home";
    if (route.name === "personas" || route.name === "persona") return "personas";
    if (route.name === "settings") return "settings";
    if (route.name === "trash") return "trash";
    return "";
  }

  function sidebar(route) {
    const active = activeKey(route);
    return `<aside class="sidebar">
      <a class="brand" href="#/" aria-label="推文帮首页">
        <span class="logo-mark">推</span>
        <span><span class="brand-name">推文帮</span><span class="brand-sub">WRITING STUDIO</span></span>
      </a>
      <nav class="nav" aria-label="主导航">
        <div class="nav-label">工作空间</div>
        ${navItems().map((n) => `<a class="nav-link ${active === n.key ? "active" : ""}" href="${n.href}">
          ${icon(n.icon)}<span>${n.label}</span>
        </a>`).join("")}
        <div class="nav-label" style="margin-top:18px">在办事项</div>
        ${activeProjects().slice(0, 4).map((p) => `<div class="nav-recent-row">
          <a class="nav-recent ${route.name === "studio" && route.id === p.id ? "active" : ""}" href="#/studio/${p.id}">
            <span class="nav-recent-title">${esc(p.title)}</span>
            <span class="nav-recent-meta">${statusLabel(p.status)}</span>
          </a>
          <button class="nav-more" data-action="project-menu" data-id="${p.id}" aria-label="更多操作">${icon("more")}</button>
        </div>`).join("") || `<span class="nav-empty">还没有稿件</span>`}
        <a class="nav-link ${active === "trash" ? "active" : ""}" href="#/trash" style="margin-top:8px">
          ${icon("trash")}<span>回收站</span>
          ${trashedProjects().length ? `<span class="count">${trashedProjects().length}</span>` : ""}
        </a>
      </nav>
      <div class="sidebar-foot">
        <button class="user-chip" data-action="account-pop" aria-label="账户">
          <span class="avatar">${esc((authUser && (authUser.name || authUser.account) || "写").slice(0, 1))}</span>
          <span><b>${esc(authUser ? (authUser.name || authUser.account) : "写作者")}</b><span>账号</span></span>
        </button>
        <a class="nav-link ${active === "settings" ? "active" : ""}" href="#/settings" style="margin-top:0">
          ${icon("settings")}<span>设置</span>
        </a>
      </div>
    </aside>`;
  }

  function mobileNav(route) {
    const active = activeKey(route);
    const items = [
      { key: "home", label: "工作台", href: "#/", icon: "home" },
      { key: "personas", label: "人设", href: "#/personas", icon: "users" },
      { key: "trash", label: "回收站", href: "#/trash", icon: "trash" },
      { key: "settings", label: "设置", href: "#/settings", icon: "settings" }
    ];
    return `<nav class="mobile-nav" aria-label="移动端导航">
      ${items.map((n) => `<a class="${active === n.key ? "active" : ""}" href="${n.href}">${icon(n.icon)}<span>${n.label}</span></a>`).join("")}
    </nav>`;
  }

  function shell(content, route, meta) {
    const title = meta.crumb || "工作台";
    return `<div class="shell">
      ${sidebar(route)}
      <div class="main">
        <header class="topbar">
          ${route.name !== "home" ? `<button class="icon-btn top-back" data-action="go-back" aria-label="返回上一页">${icon("arrowLeft")}</button>` : ""}
          <a class="mobile-brand" href="#/"><span class="logo-mark">推</span><b>推文帮</b></a>
          <div class="crumb"><span>推文帮</span><span class="sep">/</span><b>${esc(title)}</b></div>
          <div class="top-actions">
            <button class="icon-btn" data-action="toggle-theme" aria-label="切换日夜间模式">${icon(resolvedTheme() === "dark" ? "sun" : "moon")}</button>
            <a class="icon-btn" href="#/settings" aria-label="设置">${icon("settings")}</a>
            <a class="btn small primary" href="#/new?fresh=1">${icon("plus")} <span class="new-label">新建推文</span></a>
          </div>
        </header>
        <main class="page ${meta.pageClass || ""}">${content}</main>
      </div>
    </div>
    ${mobileNav(route)}`;
  }

  /* ---------------- pages ---------------- */

  function loginPage() {
    const register = ui.authMode === "register";
    return `<div class="auth">
      <section class="auth-art">
        <a class="brand auth-brand" href="#/">
          <span class="logo-mark">推</span>
          <span><span class="brand-name">推文帮</span><span class="brand-sub">WRITING STUDIO</span></span>
        </a>
        <div class="auth-art-body">
          <p class="eyebrow">LONG-FORM WRITING</p>
          <h1>为 AI 推文，<br />赋予生命力。</h1>
          <p>主题、人设、风格，只需你来定义。</p>
        </div>
        <div class="auth-art-foot">
          <span>CAT-LLM</span><span>·</span><span>Dynamic Persona Coherence</span><span>·</span><span>MAGE</span>
        </div>
      </section>
      <section class="auth-panel">
        <div class="auth-panel-top">
          <button class="icon-btn" data-action="toggle-theme-login" aria-label="切换日夜间模式" id="auth-theme">
            ${icon(resolvedTheme() === "dark" ? "sun" : "moon")}
          </button>
        </div>
        <div class="auth-form-wrap">
          <p class="eyebrow">${register ? "CREATE ACCOUNT" : "WELCOME BACK"}</p>
          <h2>${register ? "创建账户" : "登录推文帮"}</h2>
          <p class="auth-sub">${register ? "设置账号和密码，创建后即可开始写。" : "用账号和密码登录。"}</p>

          <form data-form="auth" class="auth-form" novalidate>
            ${register ? `<div class="field"><label for="auth-name">称呼</label><input class="input" id="auth-name" name="name" autocomplete="nickname" placeholder="怎么称呼你（可选）" /></div>` : ""}
            <div class="field">
              <label for="auth-account">账号</label>
              <input class="input" id="auth-account" name="account" type="text" autocomplete="username" placeholder="3–40 位账号" />
            </div>
            <div class="field">
              <label for="auth-password">密码</label>
              <input class="input" id="auth-password" name="password" type="password" autocomplete="${register ? "new-password" : "current-password"}" placeholder="至少 6 位" />
            </div>
            ${register ? `<div class="field"><label for="auth-confirm">确认密码</label><input class="input" id="auth-confirm" name="confirm" type="password" autocomplete="new-password" placeholder="再输一次" /></div>` : ""}

            <p class="auth-error" id="auth-error"></p>
            <button class="btn primary auth-submit" type="submit">${register ? "创建并登录" : "登录"}</button>
          </form>

          <p class="auth-switch">
            ${register ? "已有账号？" : "还没有账号？"}
            <button data-action="auth-mode" data-mode="${register ? "login" : "register"}">${register ? "去登录" : "创建一个"}</button>
          </p>
        </div>
      </section>
    </div>`;
  }

  function renderLogin() {
    app.innerHTML = loginPage();
    document.title = "登录 · 推文帮";
    applyTheme();
    ui.captcha = false;
    ui.captchaProgress = 0;
    requestAnimationFrame(() => {
      const input = document.getElementById("auth-account");
      if (input) input.focus();
    });
  }

  function authError(message) {
    const el = document.getElementById("auth-error");
    if (el) el.textContent = message || "";
  }

  function updateCaptcha(progress, allowComplete) {
    const track = document.querySelector("[data-captcha]");
    const handle = document.querySelector("[data-captcha-handle]");
    const fill = document.querySelector("[data-captcha-fill]");
    const label = document.querySelector("[data-captcha-label]");
    if (!track || !handle || !fill || !label) return;
    const max = Math.max(1, track.clientWidth - handle.offsetWidth - 4);
    const p = clamp(Number(progress) || 0, 0, 1);
    const left = 2 + max * p;
    handle.style.left = left + "px";
    fill.style.width = (left + handle.offsetWidth / 2) + "px";
    if (p >= 0.95 && allowComplete !== false) {
      track.classList.add("verified");
      label.textContent = "验证通过";
      handle.style.left = (max + 2) + "px";
      fill.style.width = "100%";
      ui.captcha = true;
      ui.captchaProgress = 1;
    } else {
      track.classList.remove("verified");
      label.textContent = "按住滑块，拖到最右侧";
      ui.captcha = false;
      ui.captchaProgress = p;
    }
  }

  function resetCaptcha() {
    ui.captcha = false;
    ui.captchaProgress = 0;
    const track = document.querySelector("[data-captcha]");
    if (track) track.classList.remove("verified");
    updateCaptcha(0, false);
  }

  function workRow(p) {
    const persona = getPersona(p.personaId);
    const score = projectScore(p);
    return `<a class="work-row" href="#/studio/${p.id}">
      <div class="work-title">
        <h3>${esc(p.title)}${p.sample ? '<span class="work-sample">示例</span>' : ""}</h3>
        <p><span data-time="${esc(p.updatedAt)}">${formatTime(p.updatedAt)}</span> · ${wordCount(p).toLocaleString("zh-CN")} 字</p>
      </div>
      <div class="work-persona">${personaAvatar(persona)} ${esc(persona.name)}</div>
      <div class="work-score">${score == null ? "—" : score}${score == null ? "" : "<span>/100</span>"}</div>
      <div class="work-status"><span class="status ${p.status}">${statusLabel(p.status)}</span></div>
    </a>`;
  }

  function homePage() {
    const projects = activeProjects().slice(0, 3);
    const reviewCount = activeProjects().filter((p) => p.status === "review").length;
    const published = activeProjects().filter((p) => p.status === "published").length;
    const scored = activeProjects().map((p) => projectScore(p)).filter((n) => typeof n === "number");
    const avg = scored.length ? Math.round(scored.reduce((a, b) => a + b, 0) / scored.length) : 0;
    return `<section class="home">
      <div class="home-head">
        <p class="eyebrow">${todayLabel()} · ${greeting()}</p>
        <h1>写点什么</h1>
      </div>

      <form class="composer" data-form="quick">
        <label class="composer-label" for="quick-topic">主题</label>
        <input id="quick-topic" name="topic" type="text" autocomplete="off"
          placeholder="例如：一个人在大城市生活是什么体验" />
        <div class="composer-row">
          <div class="composer-persona">
            ${personaAvatar(getPersona("shenzhi"))}
            <div class="select-wrap">
              <select name="persona" aria-label="选择人设">
                ${state.personas.map((p) => `<option value="${p.id}" ${p.id === "shenzhi" ? "selected" : ""}>${esc(p.name)} · ${esc(p.role.split(" · ")[0])}</option>`).join("")}
              </select>
            </div>
          </div>
          <button class="btn primary" type="submit">开始写 ${icon("arrowRight")}</button>
        </div>
      </form>

      <div class="home-section">
        <div class="section-head">
          <h2>最近在写</h2>
          <span class="faint" style="font-size:11px">${activeProjects().length} 篇稿件</span>
        </div>
        <div class="work-list">
          ${projects.length ? projects.map(workRow).join("") : `<div class="empty-state">还没有稿件。从上面开始写第一篇。</div>`}
        </div>
      </div>

      <div class="stats">
        <a class="stat" href="#/works?status=review"><b>${reviewCount}</b><span>待评审</span></a>
        <a class="stat" href="#/works?status=published"><b>${published}</b><span>已发布</span></a>
        <a class="stat" href="#/works?status=all"><b>${avg || "—"}</b><span>平均自检分</span></a>
      </div>
    </section>`;
  }

  function worksPage(route) {
    const status = route.params.get("status") || "all";
    const titles = { review: "待评审", published: "已发布", all: "全部稿件" };
    const list = activeProjects().filter((p) => status === "all" || p.status === status);
    return `<section class="narrow-wide">
      <div class="page-head">
        <p class="eyebrow">稿件</p>
        <h1>${titles[status] || "全部稿件"}</h1>
      </div>
      <div class="work-list">
        ${list.length ? list.map(workRow).join("") : `<div class="empty-state">这里还没有稿件。</div>`}
      </div>
    </section>`;
  }

  function trashPage() {
    const list = trashedProjects();
    return `<section class="narrow-wide">
      <div class="page-head">
        <h1>回收站</h1>
      </div>
      ${list.length ? `<div class="trash-list">
        ${list.map((p) => `<div class="trash-row">
          <div class="trash-main">
            <h3>${esc(p.title)}</h3>
            <p>${esc(getPersona(p.personaId).name)} · <span data-time="${esc(p.trashedAt || p.updatedAt || nowISO())}">${formatTime(p.trashedAt || p.updatedAt)}</span></p>
          </div>
          <div class="trash-actions">
            <button class="btn tiny ghost" data-action="restore-project" data-id="${p.id}">恢复</button>
            <button class="btn tiny ghost danger" data-action="purge-project" data-id="${p.id}">彻底删除</button>
          </div>
        </div>`).join("")}
      </div>
      <div class="trash-foot"><button class="btn small ghost" data-action="clear-trash">清空回收站</button></div>` : `<div class="empty-state">回收站是空的。</div>`}
    </section>`;
  }

  function ensureDraft(route) {
    const wantsFresh = route.params.get("fresh") === "1";
    const shouldReset = !ui.draft || (wantsFresh && !ui.freshConsumed);
    if (shouldReset) {
      ui.draft = {
        personaId: "shenzhi",
        topic: "",
        product: "",
        notes: "",
        attachments: [],
        audience: "普通读者",
        customAudience: "",
        format: "深度长文",
        customFormat: "",
        includeAdvice: false,
        pace: "fast",
        perspective: "auto",
        length: 3000,
        tone: 3,
        step: 1
      };
      // 只在进入页面时消费一次 fresh，避免每次重绘又把向导打回第一步
      ui.personaStepSeeded = false;
      if (wantsFresh) {
        ui.freshConsumed = true;
        try { history.replaceState(null, "", "#/new"); } catch (e) { /* file:// fallback */ }
      }
    }
    const personaParam = route.params.get("persona");
    if (personaParam) {
      const entering = ui.draft.personaId !== personaParam || !ui.personaStepSeeded;
      ui.draft.personaId = personaParam;
      if (entering && !route.params.get("step") && !route.params.get("topic")) {
        ui.draft.step = 2;
      }
      ui.personaStepSeeded = true;
    } else {
      ui.personaStepSeeded = false;
    }
    if (route.params.get("topic")) ui.draft.topic = route.params.get("topic");
    if (route.params.get("step")) ui.draft.step = Number(route.params.get("step")) || ui.draft.step;
    ui.step = ui.draft.step || 1;
  }

  function stepDots() {
    const steps = [
      { n: 1, label: "人设" },
      { n: 2, label: "主题" },
      { n: 3, label: "确认" }
    ];
    return `<div class="stepper" role="tablist" aria-label="新建步骤">
      ${steps.map((s) => `<button class="step ${ui.step === s.n ? "active" : ui.step > s.n ? "done" : ""}"
        data-action="wizard-step" data-step="${s.n}" role="tab" aria-selected="${ui.step === s.n}">
        <span class="step-index">0${s.n}</span>${s.label}</button>`).join("")}
    </div>`;
  }

  function newPage(route) {
    ensureDraft(route);
    const d = ui.draft;
    const persona = getPersona(d.personaId);
    const step = ui.step;
    const format = d.format || "深度长文";
    const formatDisplay = format === "自定义" ? ((d.customFormat || "").trim() || "自定义") : format;
    const audienceDisplay = d.audience === "自定义" ? ((d.customAudience || "").trim() || "自定义") : d.audience;

    const formatOption = (f) => `<button class="format-option ${format === f.value ? "active" : ""}"
      data-action="pick-format" data-value="${f.value}">
      <b>${f.label}</b><span>${f.desc}</span>
    </button>`;

    let panel = "";
    if (step === 1) {
      panel = `<div class="step-panel step-persona-panel">
        <div class="persona-options">
          ${state.personas.map((p) => `<button class="persona-option ${d.personaId === p.id ? "active" : ""}"
            data-action="pick-persona" data-id="${p.id}">
            ${personaAvatar(p)}
            <span>
              <h3>${esc(p.name)}</h3>
              <p>${esc(p.category || "")} · ${esc(p.role)}</p>
              <span class="tags">
                ${p.style.sentence.slice(0, 2).map((t) => `<span>${esc(t)}</span>`).join("")}
              </span>
            </span>
            <span class="radio-dot"></span>
          </button>`).join("")}
        </div>
      </div>`;
    } else if (step === 2) {
      panel = `<div class="step-panel">
        <div class="field">
          <label for="topic">主题</label>
          <textarea class="textarea topic-input" id="topic" data-field="topic" placeholder="写你想写的">${esc(d.topic)}</textarea>
        </div>

        <div class="field">
          <label>阅读节奏</label>
          <div class="segmented pace-options">
            <button class="${(d.pace || "fast") === "fast" ? "active" : ""}" data-action="pick-pace" data-value="fast">快节奏 · 短段落</button>
            <button class="${d.pace === "slow" ? "active" : ""}" data-action="pick-pace" data-value="slow">慢节奏 · 长段落</button>
          </div>
        </div>

        <div class="field">
          <label>叙事人称</label>
          <div class="segmented perspective-options">
            ${[["auto", "自动"], ["first", "第一人称"], ["second", "第二人称"], ["third", "第三人称"], ["objective", "无人称 · 纯客观"]].map(([v, l]) => `<button class="${(d.perspective || "auto") === v ? "active" : ""}" data-action="pick-perspective" data-value="${v}" data-hint="${esc(PERSPECTIVE_HINTS[v])}">${l}</button>`).join("")}
          </div>
          <div class="perspective-hint" id="perspective-hint">${esc(PERSPECTIVE_HINTS[d.perspective || "auto"])}</div>
        </div>

        <div class="field">
          <label>文章形态</label>
          <div class="format-grid">${FORMATS.map(formatOption).join("")}</div>
          ${format === "自定义" ? `<input class="input custom-input" id="custom-format" data-field="customFormat" value="${esc(d.customFormat || "")}" placeholder="例如：品牌故事 / 访谈 / 随笔 / 测评" />` : ""}
        </div>

        <div class="field">
          <label for="product">核心人物 / 对象</label>
          <input class="input" id="product" data-field="product" value="${esc(d.product || "")}" placeholder="选填；人物请写姓名" />
        </div>

        <div class="field">
          <label>受众</label>
          <div class="chips audience-chips">
            ${AUDIENCES.map((a) => `<button class="chip-btn ${d.audience === a ? "active" : ""}" data-action="pick-audience" data-value="${esc(a)}">${esc(a)}</button>`).join("")}
          </div>
          ${d.audience === "自定义" ? `<input class="input custom-input" id="custom-audience" data-field="customAudience" value="${esc(d.customAudience || "")}" placeholder="例如：刚毕业的女生 / 二三线城市的家长" />` : ""}
        </div>

        <div class="field-row notes-split">
          <div class="field">
            <label for="notes">素材 / 已知信息</label>
            <textarea class="textarea notes" id="notes" data-field="notes" placeholder="参数、价格、真实体验、优缺点，贴在这里">${esc(d.notes || "")}</textarea>
          </div>
          <div class="field">
            <label>图片素材</label>
            <label class="dropzone" for="image-input" data-dropzone>
              ${icon("image")}
              <span>拖图片到这里，或点击选择</span>
              <input id="image-input" type="file" accept="image/*" multiple hidden />
            </label>
            <div class="attachments">
              ${(d.attachments || []).map((a, i) => `<div class="attachment">
                <img src="${a.dataUrl}" alt="${esc(a.name)}" />
                <span>${esc(a.name)}</span>
                <button type="button" data-action="remove-attachment" data-index="${i}" aria-label="移除">${icon("close")}</button>
              </div>`).join("")}
            </div>
          </div>
        </div>

        <div class="field-row">
          <div class="field">
            <label>目标长度</label>
            <div class="length-row">
              <div class="segmented">
                ${[1500, 3000, 5000].map((n) => `<button class="${d.length === n ? "active" : ""}" data-action="pick-length" data-value="${n}">${n}</button>`).join("")}
              </div>
              <input class="input length-input" type="number" min="500" max="10000" step="100" data-field="length" value="${d.length}" aria-label="自定义字数" />
              <span class="faint" style="font-size:10px">字</span>
            </div>
          </div>
          <div class="field">
            <label>语气 <span class="slider-value" id="tone-label">${toneLabel(d.tone)}</span></label>
            <div class="range-row">
              <input type="range" min="1" max="5" step="1" value="${d.tone}" data-field="tone" aria-label="语气">
            </div>
            <div class="range-labels"><span>偏理性</span><span>平衡</span><span>偏感性</span></div>
          </div>
        </div>
      </div>`;
    } else {
      panel = `<div class="step-panel">
        <div class="summary-card">
          <div class="summary-row"><span>人设</span><b>${esc(persona.name)} · ${esc(persona.role)}</b></div>
          <div class="summary-row"><span>主题</span><b>${esc(d.topic || "未填写")}</b></div>
          <div class="summary-row"><span>文章形态</span><b>${esc(formatDisplay)}</b></div>
          <div class="summary-row"><span>核心人物 / 对象</span><b>${esc(d.product || "未指定")}</b></div>
          <div class="summary-row"><span>受众</span><b>${esc(audienceDisplay)}</b></div>
          <div class="summary-row"><span>长度</span><b>${Number(d.length).toLocaleString("zh-CN")} 字</b></div>
          <div class="summary-row"><span>阅读节奏</span><b>${(d.pace || "fast") === "slow" ? "慢节奏 · 长段落" : "快节奏 · 短段落"}</b></div>
          <div class="summary-row"><span>叙事人称</span><b>${({ auto: "自动（按人设）", first: "第一人称", second: "第二人称", third: "第三人称", objective: "无人称 · 纯客观" }[d.perspective || "auto"])}</b></div>
          <div class="summary-row"><span>语气</span><b>${toneLabel(d.tone)}</b></div>
          <div class="summary-row"><span>素材</span><b>${(d.notes || "").trim() ? `已填写 ${d.notes.trim().length} 字` : "未填写"}${(d.attachments || []).length ? ` · ${d.attachments.length} 张图片` : ""}</b></div>
        </div>
      </div>`;
    }

    return `<section class="narrow new-page">
      <div class="new-head">
        <p class="eyebrow">新建推文</p>
      </div>
      ${stepDots()}
      ${panel}
      <div class="step-actions">
        ${step > 1 ? `<button class="btn ghost" data-action="wizard-back">${icon("arrowLeft")} 上一步</button>` : `<span></span>`}
        <div class="right">
          ${step < 3
            ? `<button class="btn primary" data-action="wizard-next">下一步 ${icon("arrowRight")}</button>`
            : `<button class="btn primary" data-action="generate">${icon("spark")} 开始生成</button>`}
        </div>
      </div>
    </section>`;
  }

  function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function highlightParagraph(text, highlights) {
    const list = (highlights || [])
      .map((x) => String(x || "").trim())
      .filter((x) => x.length > 3 && text.includes(x))
      .sort((a, b) => b.length - a.length);
    if (!list.length) return esc(text);
    const re = new RegExp("(" + list.map(escapeRegExp).join("|") + ")", "g");
    return text.split(re).map((part) => list.includes(part) ? `<span class="key-sentence">${esc(part)}</span>` : esc(part)).join("");
  }

  function studioPage(route) {
    const project = getProject(route.id);
    if (!project || project.trashed) return notFoundPage();
    const persona = getPersona(project.personaId);
    const metrics = metricsFor(project);
    const score = overallScore(metrics);
    const open = unresolvedIssues(project);
    const section = ui.activeSection || 0;
    const isNew = route.params.get("new") === "1";
    const highlights = (project.review && project.review.highlights) || [];
    const readingChars = wordCount(project);
    const pace = (project.meta && project.meta.pace) || "fast";
    const readingMinutes = Math.max(1, Math.ceil(readingChars / (pace === "slow" ? 320 : 450)));
    const imageSuggestions = project.imageSuggestions || [];
    const sources = project.sources || [];
    const sectionIssues = (idx) => open.filter((i) => i.section === idx + 1);

    const outline = project.sections.map((s, i) => {
      const issues = sectionIssues(i);
      const dotClass = issues.some((x) => x.severity === "high") ? "bad" : issues.length ? "warn" : "";
      return `<button class="outline-item ${i === section ? "active" : ""}" data-action="jump-section" data-index="${i}">
        <span class="num">0${i + 1}</span>
        <span>${esc(s.title)}</span>
        <span class="dot ${dotClass}"></span>
      </button>`;
    }).join("");

    const issueMini = open.slice(0, 2).map((i) => `<div class="issue-mini">
      <span class="dot ${i.severity}"></span>
      <span>${esc(i.type)} · 第 ${i.section} 节</span>
    </div>`).join("") || `<div class="issue-mini"><span class="dot"></span><span>没有未处理的问题</span></div>`;

    const article = project.sections.map((s, i) => `<section class="editor-section" id="section-${i}" data-section="${i}">
      <div class="section-kicker">0${i + 1}</div>
      <h2 contenteditable="true" spellcheck="false" data-edit="section-title" data-section="${i}">${esc(s.title)}</h2>
      ${s.paragraphs.map((p, pi) => `<p contenteditable="true" spellcheck="false" data-edit="paragraph" data-section="${i}" data-index="${pi}" >${highlightParagraph(p, highlights)}</p>`).join("")}
    </section>`).join("");

    const passScore = Math.round(Number(state.settings.passThreshold || 0.9) * 100);
    const scoreText = score < passScore
      ? `低于通过线 ${passScore} 分`
      : open.length ? "还有 " + open.length + " 处待处理" : "没有未处理的问题";
    const canPublish = score >= passScore && !open.some((i) => i.severity === "high");
    const statusText = isNew ? "初稿已生成" : statusLabel(project.status);

    return `<section class="studio">
      <div class="studio-head">
        <a class="back-link" href="#/">${icon("arrowLeft")} 工作台</a>
        <div class="studio-title-wrap">
          <div class="studio-title" contenteditable="true" spellcheck="false" data-edit="title" role="textbox" aria-label="文章标题">${esc(project.title)}</div>
          <div class="studio-meta">
            ${personaAvatar(persona, "tiny")}
            <span>${esc(persona.name)}</span><span>·</span><span>${esc(persona.role.split(" · ")[0])}</span>
            <span class="chip">${statusText}</span>
            ${project.meta && project.meta.format ? `<span class="chip">${esc(project.meta.format)}</span>` : ""}
            <span>v${project.version}</span>
            <span>${wordCount(project).toLocaleString("zh-CN")} 字</span>
            ${project.sample ? `<span class="chip">示例稿</span>` : ""}
          </div>
        </div>
        <div class="studio-actions">
          <button class="btn ghost small" data-action="save-project">保存</button>
          <button class="btn ghost small" data-action="export-project">${icon("download")} 导出</button>
          <button class="btn primary small" data-action="open-review">${icon("check")} 自检</button>
        </div>
      </div>

      <div class="reading-bar">
        <span class="reading-label">阅读时间</span>
        <b>约 ${readingMinutes} 分钟</b>
        <span class="faint">${readingChars.toLocaleString("zh-CN")} 字 · ${pace === "slow" ? "慢节奏" : "快节奏"}</span>
      </div>

      <div class="studio-grid">
        <aside class="outline" aria-label="文章提纲">
          <div class="outline-head"><span>提纲</span><span>${project.sections.length} 节</span></div>
          <div class="outline-list">${outline}</div>
        </aside>

        <article class="editor">
          <div class="editor-top">
            <div class="editor-tools">
              <button class="btn tiny ghost" data-action="polish-section">${icon("spark")} 润色本节</button>
              <button class="btn tiny ghost" data-action="open-review">${icon("check")} AI 痕迹</button>
            </div>
            <span class="word-count">${wordCount(project).toLocaleString("zh-CN")} 字 · 自动保存</span>
          </div>
          <div class="editor-inner">
            ${article}
            ${imageSuggestions.length ? `<section class="image-suggestions">
              <div class="image-suggestions-head"><h3>配图建议</h3><span>点击搜索图片</span></div>
              <div class="image-chips">
                ${imageSuggestions.map((q) => `<a class="image-chip" href="https://image.baidu.com/search/index?tn=baiduimage&word=${encodeURIComponent(q)}" target="_blank" rel="noopener">${esc(q)}</a>`).join("")}
              </div>
            </section>` : ""}
            ${sources.length ? `<details class="source-box">
              <summary>参考来源 ${sources.length}</summary>
              <ul>${sources.map((src) => `<li><a href="${esc(src.url)}" target="_blank" rel="noopener">${esc(src.title)}</a></li>`).join("")}</ul>
            </details>` : ""}
          </div>
        </article>

        <aside class="insight" aria-label="自检摘要">
          <div class="insight-head"><h2>自检摘要</h2><span>PCC · MAGE</span></div>
          <div class="score-block">
            ${scoreRing(score)}
            <div class="score-copy">
              <b>${canPublish ? "可以发布" : score >= passScore - 5 ? "接近通过" : "先改再发"}</b>
              <span>${scoreText}</span>
            </div>
          </div>
          ${metricBar("人设一致性", metrics.persona)}
          ${metricBar("风格相似", metrics.style)}
          ${metricBar("内容质量", metrics.content)}
          ${metricBar("人味", metrics.human, true)}
          <div class="insight-issues">
            <h3>待处理</h3>
            ${issueMini}
          </div>
          <a class="btn small" href="#/review/${project.id}">查看完整评审 ${icon("arrowRight")}</a>
        </aside>
      </div>

      <div class="pipeline" aria-label="生成流水线">
        ${pipeStep("01", "人设解析", "L/M/S + 风格卡", "done")}
        ${pipeStep("02", "正文生成", "CAT-LLM · 分段生成", "done")}
        ${pipeStep("03", "润色去 AI 化", "PDS · 定向改写", project.status === "draft" ? "" : "done")}
        ${pipeStep("04", "自检评估", "PCC + MAGE", project.status === "review" ? "active" : "done")}
      </div>
    </section>`;
  }

  function metricBar(label, value, sage) {
    return `<div class="metric">
      <div class="metric-line"><span>${label}</span><b>${value}</b></div>
      <div class="metric-bar"><i class="${sage ? "sage" : ""}" style="width:${clamp(value, 0, 100)}%"></i></div>
    </div>`;
  }

  function pipeStep(num, title, desc, state) {
    return `<div class="pipe-step ${state}">
      <div class="pipe-kicker"><span class="pipe-dot"></span>${num}</div>
      <h4>${title}</h4>
      <p>${desc}</p>
    </div>`;
  }

  function reviewPage(route) {
    const project = getProject(route.id);
    if (!project || project.trashed) return notFoundPage();
    const persona = getPersona(project.personaId);
    const metrics = metricsFor(project);
    const score = overallScore(metrics);
    const issues = (project.review && project.review.issues) || [];
    const open = issues.filter((i) => !i.resolved);
    const high = open.filter((i) => i.severity === "high");
    const passScore = Math.round(Number(state.settings.passThreshold || 0.9) * 100);
    const belowPass = score < passScore;
    const verdict = high.length
      ? "先改这几处，再发。"
      : belowPass
        ? "再改一轮，再发。"
        : open.length
          ? "可以发，但还能更好。"
          : "可以发布。";
    const sub = high.length
      ? `有 ${high.length} 处 high 级问题，建议逐条处理后再发。`
      : belowPass
        ? `当前 ${score} 分，通过线 ${passScore} 分。先把分数拉上去。`
        : open.length
          ? `还剩 ${open.length} 处小问题，改完会更像他。`
          : "人设、风格、事实都过了。可以进入发布流程。";
    const firstOpen = open[0] ? open[0].id : null;

    return `<section class="narrow-wide">
      <div class="page-head" style="margin-bottom:18px">
        <p class="eyebrow">自检报告 · ${esc(persona.name)}</p>
      </div>
      <div class="review-hero">
        <div class="score-big">${score}<span>/ 100</span></div>
        <div>
          <h1>${verdict}</h1>
          <p class="lede">${sub}</p>
          <div style="display:flex;gap:8px;align-items:center;margin-top:14px;flex-wrap:wrap">
            <span class="chip">${issues.length} 项检查</span>
            <span class="chip">${open.length} 项待处理</span>
            <span class="chip">${high.length} 项 high</span>
            <a class="chip" href="#/studio/${project.id}">返回写作台 ${icon("arrowRight")}</a>
          </div>
        </div>
      </div>

      <div class="metrics-grid">
        ${metricCard("人设一致性", metrics.persona, "锚点 + 语气")}
        ${metricCard("风格相似", metrics.style, "词 / 句 / 篇")}
        ${metricCard("内容质量", metrics.content, "论点 / 证据")}
        ${metricCard("人味", metrics.human, `AI 痕迹 ${100 - metrics.human}`)}
      </div>

      <div class="issues-head">
        <h2>问题清单</h2>
        <span>按严重程度排序 · 点击展开证据与建议</span>
      </div>
      <div class="issues">
        ${issues.map((issue, idx) => issueRow(issue, issue.id === firstOpen)).join("") || `<div class="empty-state">没有发现问题。可以发布。</div>`}
      </div>

      <div class="review-actions">
        <p class="review-note">评分只是体检，不是判决。事实问题必须人工核实；风格判断建议至少两位编辑交叉看一眼。</p>
        <div class="right">
          <button class="btn ghost" data-action="run-check">${icon("refresh")} 重新自检</button>
          <button class="btn primary" data-action="publish-project">通过并发布 ${icon("arrowRight")}</button>
        </div>
      </div>
    </section>`;
  }

  function metricCard(label, value, hint) {
    return `<div class="metric-card">
      <div class="metric-top"><span>${label}</span><b>${value}</b></div>
      <div class="metric-bar"><i style="width:${clamp(value, 0, 100)}%"></i></div>
      <div class="faint" style="font-size:9.5px;margin-top:7px">${hint}</div>
    </div>`;
  }

  function issueRow(issue, openDefault) {
    const resolved = !!issue.resolved;
    const sev = issue.severity || "low";
    return `<details class="issue ${resolved ? "resolved" : ""}" ${openDefault && !resolved ? "open" : ""}>
      <summary>
        <span class="sev-dot ${sev}"></span>
        <span class="issue-title"><b>${esc(issue.type)}</b><span>第 ${issue.section} 节 · ${esc(issue.quote)}</span></span>
        <span class="issue-tag">${resolved ? "已处理" : sev === "high" ? "高优先级" : sev === "medium" ? "中优先级" : "低优先级"}</span>
        ${icon("chevron", "chev")}
      </summary>
      <div class="issue-body">
        <div class="issue-quote">“${esc(issue.quote)}”</div>
        <div class="issue-evidence"><span>判断依据</span><div>${esc(issue.evidence)}</div></div>
        <div class="issue-evidence"><span>修改建议</span><div>${esc(issue.suggestion)}</div></div>
        <div class="issue-evidence"><span>回退路由</span><div>${esc(issue.route)}</div></div>
        <div class="issue-actions">
          ${resolved
            ? `<span class="chip accent">已处理</span>`
            : issue.fix === "fact"
              ? `<button class="btn small" data-action="fix-issue" data-id="${issue.id}">标记已核实</button><span class="faint" style="font-size:10px">需要人工核对原始来源</span>`
              : issue.fix === "rewrite"
                ? `<button class="btn small primary" data-action="fix-issue" data-id="${issue.id}">按建议重写 ${icon("arrowRight")}</button>`
                : issue.fix === "remove"
                  ? `<button class="btn small primary" data-action="fix-issue" data-id="${issue.id}">按建议删掉 ${icon("arrowRight")}</button>`
                  : `<button class="btn small" data-action="fix-issue" data-id="${issue.id}">标记已处理</button>`}
        </div>
      </div>
    </details>`;
  }

  function personasPage() {
    return `<section>
      <div class="page-head">
        <h1>人设库</h1>
      </div>
      <div class="persona-grid">
        ${state.personas.map((p) => `<article class="persona-card">
          <a href="#/persona/${p.id}" aria-label="查看 ${esc(p.name)} 的人设">
            <div class="persona-card-top">
              ${personaAvatar(p)}
              <div><h3>${esc(p.name)}</h3><div class="role">${esc(p.role)}</div></div>
            </div>
            <div class="tags">${(p.style.sentence || []).slice(0, 3).map((t) => `<span>${esc(t)}</span>`).join("")}</div>
          </a>
          <div class="persona-card-foot">
            <div class="lms-mini">
              <span>M <b>${p.M.meaning}</b></span>
              <span>S <b>${p.S}</b></span>
              <span>锚点 <b>${p.L.length}</b></span>
            </div>
            <div class="persona-card-actions">
              <a class="btn tiny ghost" href="#/persona/${p.id}/edit">修改</a>
              <a class="btn tiny ghost" href="#/new?persona=${p.id}&fresh=1">用 Ta 写 ${icon("arrowRight")}</a>
            </div>
          </div>
        </article>`).join("")}
        <a class="persona-add" href="#/persona/new">
          ${icon("plus")}
          <span>新建人设</span>
        </a>
      </div>
    </section>`;
  }

  function personaPage(route) {
    const p = state.personas.find((x) => x.id === route.id);
    if (!p) return notFoundPage();
    return `<section class="narrow-wide">
      <a class="back-link persona-back" href="#/personas">${icon("arrowLeft")} 返回人设库</a>
      <div class="persona-detail-head">
        ${personaAvatar(p)}
        <div>
          <div class="role">${esc(p.category || "通用")}</div>
          <h1>${esc(p.name)}</h1>
          <div class="role">${esc(p.role)}</div>
        </div>
        <div class="persona-head-actions">
          <a class="btn" href="#/persona/${p.id}/edit">${icon("pen")} 修改</a>
          <a class="btn primary" href="#/new?persona=${p.id}&fresh=1">用 Ta 写 ${icon("arrowRight")}</a>
        </div>
      </div>

      <div class="detail-grid">
        <div>
          <section class="detail-section">
            <h2>锚点 <span>ANCHOR</span></h2>
            <ol class="anchor-list">${p.L.map((x) => `<li>${esc(x)}</li>`).join("")}</ol>
          </section>
          <section class="detail-section">
            <h2>默认状态 <span>STATE</span></h2>
            <div class="state-row"><span class="label">意义感</span><div class="bar"><i style="width:${p.M.meaning * 10}%"></i></div><b>${p.M.meaning}</b></div>
            <div class="state-row"><span class="label">压力</span><div class="bar"><i style="width:${p.M.strain * 10}%"></i></div><b>${p.M.strain}</b></div>
            <div class="state-row"><span class="label">情绪</span><div class="bar"><i class="sage" style="width:${p.S * 10}%"></i></div><b>${p.S}</b></div>
          </section>
        </div>

        <div>
          <section class="detail-section">
            <h2>风格 <span>STYLE</span></h2>
            <div class="style-groups">
              <div class="style-group"><div class="label">用词</div><div class="tags">${p.style.word.map((t) => `<span>${esc(t)}</span>`).join("")}</div></div>
              <div class="style-group"><div class="label">句子</div><div class="tags">${p.style.sentence.map((t) => `<span>${esc(t)}</span>`).join("")}</div></div>
              <div class="style-group"><div class="label">结构</div><div class="tags">${p.style.discourse.map((t) => `<span>${esc(t)}</span>`).join("")}</div></div>
            </div>
          </section>
          <section class="detail-section">
            <h2>小传 <span>BIO</span></h2>
            <p style="font-size:13px;color:var(--muted);line-height:1.8">${esc(p.bio)}</p>
          </section>
        </div>
      </div>
    </section>`;
  }

  function personaEditPage(route) {
    const isNew = route.id === "new";
    const p = isNew ? null : state.personas.find((x) => x.id === route.id);
    if (!isNew && !p) return notFoundPage();
    const d = p || {
      id: "",
      name: "",
      role: "",
      category: "通用",
      bio: "",
      accent: "#B4452A",
      L: [],
      style: { word: [], sentence: [], discourse: [] },
      anti: [],
      M: { meaning: 5, strain: 5 },
      S: 5
    };
    const anchors = [...(d.L || []), ...((d.anti || []).map((x) => `不写：${x}`))].join("\n");
    return `<section class="narrow">
      <a class="back-link persona-back" href="${isNew ? "#/personas" : `#/persona/${d.id}`}">${icon("arrowLeft")} 返回</a>
      <div class="page-head"><h1>${isNew ? "新建人设" : "编辑人设"}</h1></div>
      <form class="persona-form" data-form="persona" data-persona-id="${esc(d.id)}">
        <div class="field-row">
          <div class="field"><label for="p-name">名字</label><input class="input" id="p-name" name="name" value="${esc(d.name)}" placeholder="例如：陆衡" required></div>
          <div class="field"><label for="p-cat">分类</label><input class="input" id="p-cat" name="category" value="${esc(d.category || "")}" placeholder="例如：财经 / 新闻 / 科技 / 自定义"></div>
        </div>
        <div class="field"><label for="p-role">身份</label><input class="input" id="p-role" name="role" value="${esc(d.role)}" placeholder="例如：财经观察 · 前投行分析师" required></div>

        <div class="analyze-box">
          <label for="p-samples">粘贴样稿，自动分析</label>
          <textarea class="textarea" id="p-samples" placeholder="把这个人设写过的 1–3 篇文章贴在这里，点“分析并填写”。"></textarea>
          <div class="analyze-actions">
            <button type="button" class="btn small" data-action="analyze-persona">分析并填写</button>
            <span class="faint" id="analyze-status" style="font-size:10px"></span>
          </div>
        </div>

        <div class="field"><label for="p-bio">小传</label><textarea class="textarea" id="p-bio" name="bio" placeholder="他做过什么、在意什么、为什么写。">${esc(d.bio)}</textarea></div>
        <div class="field-row">
          <div class="field"><label for="p-accent">标记色</label><input class="input color-input" id="p-accent" name="accent" type="color" value="${esc(d.accent)}"></div>
          <div class="field"><label>默认状态</label><div class="state-inputs">
            <label>意义 <input type="number" name="mMeaning" min="0" max="10" value="${d.M.meaning}"></label>
            <label>压力 <input type="number" name="mStrain" min="0" max="10" value="${d.M.strain}"></label>
            <label>情绪 <input type="number" name="sVal" min="0" max="10" value="${d.S}"></label>
          </div></div>
        </div>

        <div class="field">
          <label for="p-L">锚点</label>
          <textarea class="textarea" id="p-L" name="L" placeholder="一行一条：他相信什么、怎么写、绝不写什么。">${esc(anchors)}</textarea>
        </div>

        <div class="form-grid-3">
          <div class="field"><label for="p-word">用词</label><textarea class="textarea" id="p-word" name="word" placeholder="例如：短词、成本/参数类名词、少用形容词、偶尔自嘲">${esc((d.style.word || []).join("\n"))}</textarea></div>
          <div class="field"><label for="p-sentence">句子</label><textarea class="textarea" id="p-sentence" name="sentence" placeholder="例如：平均 18–25 字、长短句交替、每 2–3 段一个反问">${esc((d.style.sentence || []).join("\n"))}</textarea></div>
          <div class="field"><label for="p-discourse">结构</label><textarea class="textarea" id="p-discourse" name="discourse" placeholder="例如：开头直接给判断、每节一个小标题、结尾不喊口号">${esc((d.style.discourse || []).join("\n"))}</textarea></div>
        </div>

        <div class="form-actions">
          ${isNew ? "" : `<button type="button" class="btn ghost danger" data-action="delete-persona" data-id="${d.id}">删除人设</button>`}
          <span style="flex:1"></span>
          <a class="btn ghost" href="${isNew ? "#/personas" : `#/persona/${d.id}`}">取消</a>
          <button class="btn primary" type="submit">${isNew ? "创建人设" : "保存修改"}</button>
        </div>
      </form>
    </section>`;
  }

  function settingsPage() {
    const s = state.settings;
    const banned = (s.bannedPhrases || []).join("\n");
    return `<section class="settings">
      <div class="page-head settings-head">
        <h1>设置</h1>
      </div>

      <div class="settings-group">
        <h2>外观</h2>
        <div class="setting-row">
          <label>主题</label>
          <div>
            <div class="theme-options">
              ${themeOption("light", "日间", "sun")}
              ${themeOption("dark", "夜间", "moon")}
              ${themeOption("system", "跟随系统", "monitor")}
            </div>
          </div>
        </div>
        <div class="setting-row">
          <label>阅读宽度</label>
          <div>
            <div class="segmented">
              ${["narrow", "normal", "wide"].map((r) => `<button class="${s.reading === r ? "active" : ""}" data-action="set-reading" data-value="${r}">${r === "narrow" ? "窄" : r === "normal" ? "中" : "宽"}</button>`).join("")}
            </div>
            <div class="reading-preview"><p>夜里十一点，县城的车站已经关了灯。最后一班车晚点了四十分钟，候车室里只剩下三个人。工作人员说，路上下雪，车可能还要再等一会儿。</p></div>
          </div>
        </div>
        <div class="setting-row">
          <label>字号</label>
          <div>
            <div class="segmented">
              ${[["small", "小"], ["normal", "标准"], ["large", "大"]].map(([v, l]) => `<button class="${Number(s.fontScale) === ({ small: 0.95, normal: 1.04, large: 1.12 }[v]) ? "active" : ""}" data-action="set-font" data-value="${v}">${l}</button>`).join("")}
            </div>
          </div>
        </div>
      </div>

      <div class="settings-group">
        <h2>自检阈值</h2>
        <div class="setting-row">
          <label>PDS 触发阈值 <span class="slider-value" id="pds-value">${Number(s.pdsThreshold).toFixed(2)}</span></label>
          <div>
            <div class="range-row"><input type="range" min="0.6" max="0.9" step="0.01" value="${s.pdsThreshold}" data-setting="pdsThreshold"></div>
            <div class="range-labels"><span>更严格 · 0.60</span><span>更宽松 · 0.90</span></div>
          </div>
        </div>
        <div class="setting-row">
          <label>通过阈值 <span class="slider-value" id="pass-value">${Number(s.passThreshold).toFixed(2)}</span></label>
          <div>
            <div class="range-row"><input type="range" min="0.8" max="0.98" step="0.01" value="${s.passThreshold}" data-setting="passThreshold"></div>
            <div class="range-labels"><span>更宽松 · 0.80</span><span>更严格 · 0.98</span></div>
          </div>
        </div>
      </div>

      <div class="settings-group">
        <h2>写作规则</h2>
        <div class="field">
          <label for="banned-input">全局禁用</label>
          <textarea class="textarea banned-input" id="banned-input" placeholder="一行一个词或短语">${esc(banned)}</textarea>
          <div class="field-hint">生成、润色、自检都会避开这些词。</div>
        </div>
        <div class="settings-actions">
          <button class="btn small" data-action="save-banned">保存规则</button>
        </div>
      </div>

      <div class="settings-group">
        <h2>数据</h2>
        <div class="settings-actions">
          <button class="btn small" data-action="export-data">${icon("download")} 导出全部数据</button>
          <button class="btn small ghost" data-action="reset-data">恢复示例数据</button>
        </div>
      </div>

      <div class="settings-group">
        <h2>关于</h2>
        <div class="about-line"><span>版本</span><b>推文帮 v2.0 · 本地版</b></div>
        <div class="about-line"><span>生成服务</span><b id="api-status">检查中…</b></div>
        <div class="about-line"><span>方法来源</span><b>CAT-LLM · Dynamic Persona Coherence · MAGE</b></div>
      </div>
    </section>`;
  }

  function themeOption(value, label, ic) {
    return `<button class="theme-option ${themePref() === value ? "active" : ""}" data-action="set-theme" data-value="${value}">
      ${icon(ic)} ${label}</button>`;
  }

  function notFoundPage() {
    return `<section class="narrow" style="text-align:center;padding-top:80px">
      <p class="eyebrow" style="justify-content:center">404</p>
      <h1 style="font-size:40px;margin:18px 0">这一页还没有写。</h1>
      <p class="lede" style="margin-bottom:24px">回到工作台，从一个人设和一个主题开始。</p>
      <a class="btn primary" href="#/">回到工作台</a>
    </section>`;
  }

  /* ---------------- generation ---------------- */

  const GEN_STAGES = [
    { step: 1, label: "人设解析", paper: "L/M/S", title: "正在读人设", sub: "把锚点、风格和受众放进上下文" },
    { step: 2, label: "正文生成", paper: "CAT-LLM", title: "正在搭骨架", sub: "先定角度，再排提纲" },
    { step: 3, label: "润色去 AI 化", paper: "PDS", title: "正在润色", sub: "调节奏、删模板句，保留事实和观点" },
    { step: 4, label: "自检评估", paper: "MAGE", title: "正在自检", sub: "人设、风格、AI 痕迹、事实四项打分" }
  ];

  function showGeneration() {
    overlayEl.innerHTML = `<div class="overlay-bg" role="dialog" aria-modal="true" aria-label="正在生成">
      <div class="gen-card" id="gen-card">
        <div class="gen-top">
          <p class="eyebrow">正在生成</p>
          <span id="gen-percent">0%</span>
        </div>
        <h2 id="gen-title">正在读人设</h2>
        <p id="gen-sub">${GEN_STAGES[0].sub}</p>
        <div class="gen-progress"><i id="gen-bar"></i></div>
        <div class="gen-steps">
          ${GEN_STAGES.map((s, i) => `<div class="gen-step" data-gen-step="${i}">
            <span class="mark">${String(i + 1).padStart(2, "0")}</span>
            <span class="gen-step-label">${s.label}</span>
            <span class="paper">${s.paper}</span>
          </div>`).join("")}
        </div>
        <div class="gen-live" id="gen-live">连接模型…</div>
        <div class="gen-foot"><span>DeepSeek · 服务端生成</span><span><span id="gen-status">准备中</span> · <button class="gen-cancel" data-action="close-generation">取消</button></span></div>
      </div>
    </div>`;
    document.body.style.overflow = "hidden";
    setGenPercent(2);
  }

  function setGenPercent(value) {
    const pct = clamp(Math.round(Number(value) || 0), 0, 100);
    const bar = document.getElementById("gen-bar");
    const label = document.getElementById("gen-percent");
    if (bar) bar.style.width = pct + "%";
    if (label) label.textContent = pct + "%";
  }

  function setGenLive(text) {
    const el = document.getElementById("gen-live");
    if (el) el.textContent = text;
  }

  function updateGenStage(data) {
    if (!data) return;
    const step = Number(data.step) || 1;
    const rows = Array.from(document.querySelectorAll("[data-gen-step]"));
    rows.forEach((row, i) => {
      row.classList.toggle("active", i === step - 1);
      row.classList.toggle("done", i < step - 1);
    });
    const title = document.getElementById("gen-title");
    const sub = document.getElementById("gen-sub");
    if (title && data.title) title.textContent = data.title;
    if (sub && data.sub) sub.textContent = data.sub;
    if (data.percent != null) setGenPercent(data.percent);
  }

  function clearGeneration() {
    if (ui.genAbort) {
      try { ui.genAbort.abort(); } catch (e) { /* ignore */ }
      ui.genAbort = null;
    }
    if (ui.genTimer) {
      clearInterval(ui.genTimer);
      ui.genTimer = null;
    }
    overlayEl.innerHTML = "";
    document.body.style.overflow = "";
  }

  function showGenError(message) {
    if (ui.genTimer) {
      clearInterval(ui.genTimer);
      ui.genTimer = null;
    }
    const card = document.getElementById("gen-card");
    if (!card) return;
    card.innerHTML = `<p class="eyebrow">生成中断</p>
      <h2>这次没写成。</h2>
      <p class="gen-error">${esc(message || "生成失败，请稍后重试。")}</p>
      <div class="gen-actions">
        <button class="btn ghost" data-action="close-generation">返回修改</button>
        <button class="btn primary" data-action="retry-generation">${icon("refresh")} 重试</button>
      </div>
      <div class="gen-foot"><span>请求没有产生稿件</span><span>可以调整主题或素材后再试</span></div>`;
  }

  function parseSSE(block) {
    let event = "message";
    const dataLines = [];
    block.split("\n").forEach((line) => {
      if (line.startsWith("event:")) event = line.slice(6).trim();
      else if (line.startsWith("data:")) dataLines.push(line.slice(5).trim());
    });
    if (!dataLines.length) return null;
    try {
      return { event, data: JSON.parse(dataLines.join("\n")) };
    } catch (e) {
      return null;
    }
  }

  function handleGenEvent(event, data) {
    if (event === "stage") {
      updateGenStage(data);
      if (data.live) setGenLive(data.live);
      else if (data.sub) setGenLive(data.sub);
    } else if (event === "plan") {
      setGenPercent(18);
      setGenLive(`提纲已生成：${data.outline ? data.outline.length : 0} 节 · 开始写正文`);
    } else if (event === "section") {
      updateGenStage({
        step: 2,
        title: `正在写第 ${data.index} 节`,
        sub: `${data.title}`,
        percent: data.percent
      });
      setGenLive(`第 ${data.index}/${data.total} 节已完成：${data.title}`);
    } else if (event === "polish") {
      setGenPercent(90);
      setGenLive("润色完成 · 事实和观点已保留");
    } else if (event === "clarify") {
      showGenError(data.message || "请补全主题里的核心人物或对象。");
      if (ui.genAbort) ui.genAbort.abort();
    } else if (event === "warning") {
      setGenLive(`提示：${data.message}`);
    } else if (event === "review") {
      setGenPercent(99);
      const s = data.scores || {};
      setGenLive(`自检完成：人设 ${s.persona ?? "-"} · 风格 ${s.style ?? "-"} · 内容 ${s.content ?? "-"} · 人味 ${s.human ?? "-"}`);
    }
  }

  function finishGeneration(project) {
    if (!project) {
      showGenError("服务端没有返回稿件。");
      return;
    }
    project.status = "review";
    state.projects.unshift(project);
    saveState();
    clearGeneration();
    ui.activeSection = 0;
    ui.draft = null;
    ui.step = 1;
    ui.lastPayload = null;
    location.hash = `#/studio/${project.id}?new=1`;
    setTimeout(() => toast("初稿已生成。先读一遍，再去自检。"), 450);
  }

  function basePayload() {
    const d = ui.draft;
    return {
      personaId: d.personaId,
      persona: getPersona(d.personaId),
      topic: (d.topic || "").trim(),
      product: (d.product || "").trim(),
      audience: d.audience === "自定义" ? ((d.customAudience || "").trim() || "普通读者") : d.audience,
      length: d.length,
      tone: d.tone,
      pace: d.pace || "fast",
      perspective: d.perspective || "auto",
      format: d.format === "自定义" ? ((d.customFormat || "").trim() || "自定义") : (d.format || "深度长文"),
      includeAdvice: false,
      notes: (d.notes || "").trim(),
      attachments: (d.attachments || []).map((a) => a.name),
      banned: state.settings.bannedPhrases || []
    };
  }

  function validateDraftForGeneration() {
    const d = ui.draft;
    if (!d) return false;
    const topic = (d.topic || "").trim();
    if (!topic) {
      toast("先给一个主题，再开始生成");
      return false;
    }
    const ambiguousPerson = /(这个|这位|那个|某位|某个)(公众人物|明星|演员|歌手|作家|主持人|导演|运动员|网红|企业家)/.test(topic);
    if (ambiguousPerson && !(d.product || "").trim()) {
      toast("主题里像是具体人物，但没有名字。请在“核心人物 / 对象”里补上姓名。", 4200);
      ui.step = 2;
      ui.draft.step = 2;
      render();
      requestAnimationFrame(() => {
        const input = document.getElementById("product");
        if (input) { input.focus(); input.scrollIntoView({ block: "center", behavior: "smooth" }); }
      });
      return false;
    }
    return true;
  }

  function closeWorkflow() {
    overlayEl.innerHTML = "";
    document.body.style.overflow = "";
  }

  function showWorkflowLoading(message) {
    overlayEl.innerHTML = `<div class="workflow-shade"></div>
      <div class="workflow-modal workflow-loading">
        <span class="loading-dot"></span>
        <p>${esc(message || "正在准备…")}</p>
      </div>`;
    document.body.style.overflow = "hidden";
  }

  function showWorkflowError(message) {
    overlayEl.innerHTML = `<div class="workflow-shade" data-action="workflow-close"></div>
      <div class="workflow-modal workflow-error">
        <p class="eyebrow">没有完成</p>
        <h3>还差一步</h3>
        <p>${esc(message || "请稍后重试。")}</p>
        <div class="workflow-actions"><button class="btn primary" data-action="workflow-close">关闭</button></div>
      </div>`;
    document.body.style.overflow = "hidden";
  }

  async function openTitlePicker() {
    if (!ui.draft || !validateDraftForGeneration()) return;
    ui.titleData = null;
    ui.outlineData = null;
    ui.selectedTitleIndex = 0;
    showWorkflowLoading("正在检索资料，生成 5 个标题…");
    try {
      const response = await fetch("/api/titles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(basePayload())
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "标题生成失败");
      ui.titleData = data;
      renderTitleModal();
    } catch (err) {
      showWorkflowError(err.message || "标题生成失败，请重试。");
    }
  }

  function titleCard(t, i, selected) {
    return `<label class="title-choice ${selected ? "active" : ""}">
      <input type="radio" name="workflow-title" value="${i}" ${selected ? "checked" : ""} />
      <span class="title-choice-main">
        <input class="title-choice-input" data-title-index="${i}" value="${esc(t.title)}" placeholder="写一个标题" />
        <span class="title-choice-meta">${esc(t.type || "方向")}${t.angle ? ` · ${esc(t.angle)}` : ""}</span>
      </span>
    </label>`;
  }

  function renderTitleModal() {
    if (!ui.titleData) return;
    const titles = ui.titleData.titles || [];
    overlayEl.innerHTML = `<div class="workflow-shade"></div>
      <div class="workflow-modal">
        <p class="eyebrow">第一步 · 标题</p>
        <h3>先选一个标题</h3>
        <p class="workflow-sub">${ui.titleData.sources && ui.titleData.sources.length ? `参考了 ${ui.titleData.sources.length} 条网络资料，标题和角度都可以改。` : "标题和角度都可以改。"}</p>
        <div class="title-list">
          ${titles.map((t, i) => titleCard(t, i, i === ui.selectedTitleIndex)).join("")}
        </div>
        <div class="workflow-actions">
          <button class="btn ghost" data-action="workflow-close">取消</button>
          <button class="btn ghost" data-action="workflow-refresh-titles">换一批</button>
          <span style="flex:1"></span>
          <button class="btn primary" data-action="workflow-generate-outlines">下一步：生成大纲 ${icon("arrowRight")}</button>
        </div>
      </div>`;
    document.body.style.overflow = "hidden";
  }

  function saveTitleEdits() {
    if (!ui.titleData) return;
    document.querySelectorAll("[data-title-index]").forEach((input) => {
      const i = Number(input.dataset.titleIndex);
      if (ui.titleData.titles[i]) ui.titleData.titles[i].title = input.value;
    });
  }

  async function generateOutlines() {
    saveTitleEdits();
    const chosen = ui.titleData.titles[ui.selectedTitleIndex];
    const title = chosen && chosen.title.trim();
    if (!title) {
      toast("先选一个标题，或把标题写完整");
      return;
    }
    showWorkflowLoading("正在根据这个标题，生成 3 种大纲…");
    try {
      const response = await fetch("/api/outlines", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(Object.assign(basePayload(), { selectedTitle: title }))
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "大纲生成失败");
      if (!data.outlines || !data.outlines.length) throw new Error("没有生成有效大纲");
      ui.outlineData = data;
      ui.outlineData.selectedTitle = title;
      ui.selectedOutlineIndex = 0;
      renderOutlineModal();
    } catch (err) {
      showWorkflowError(err.message || "大纲生成失败，请重试。");
    }
  }

  function outlineSectionEditor(section, i) {
    return `<div class="outline-edit-section" data-outline-section="${i}">
      <div class="outline-edit-part"><span>${esc(section.part || (i === 0 ? "开头" : "中间"))}</span></div>
      <input class="input" data-section-field="title" value="${esc(section.title)}" placeholder="小节标题" />
      <textarea class="textarea" data-section-field="goal" placeholder="这一节大概写什么">${esc(section.goal || "")}</textarea>
      <textarea class="textarea outline-points" data-section-field="points" placeholder="要点，一行一条">${esc((section.key_points || []).join("\n"))}</textarea>
    </div>`;
  }

  function renderOutlineModal() {
    if (!ui.outlineData) return;
    const outlines = ui.outlineData.outlines || [];
    const current = outlines[ui.selectedOutlineIndex];
    if (!current) return;
    overlayEl.innerHTML = `<div class="workflow-shade"></div>
      <div class="workflow-modal workflow-outline-modal">
        <p class="eyebrow">第二步 · 大纲</p>
        <h3>选一个结构，再改细节</h3>
        <div class="outline-tabs">
          ${outlines.map((o, i) => `<button class="${i === ui.selectedOutlineIndex ? "active" : ""}" data-action="workflow-select-outline" data-index="${i}">大纲 ${String.fromCharCode(65 + i)}</button>`).join("")}
        </div>
        <div class="outline-edit">
          <div class="field"><label>标题</label><input class="input" data-outline-field="title" value="${esc(current.title || ui.outlineData.selectedTitle || "")}" /></div>
          <div class="field"><label>中心判断</label><textarea class="textarea" data-outline-field="thesis" placeholder="这篇要说什么">${esc(current.thesis || "")}</textarea></div>
          <div class="field"><label>要回答的问题</label><textarea class="textarea" data-outline-field="central_question" placeholder="读者关心的问题">${esc(current.central_question || "")}</textarea></div>
          <div class="outline-sections">
            ${current.sections.map((s, i) => outlineSectionEditor(s, i)).join("")}
          </div>
        </div>
        <div class="workflow-actions">
          <button class="btn ghost" data-action="workflow-back-titles">上一步</button>
          <button class="btn ghost" data-action="workflow-refresh-outlines">换一批</button>
          <span style="flex:1"></span>
          <button class="btn primary" data-action="workflow-start">按这个大纲生成 ${icon("arrowRight")}</button>
        </div>
      </div>`;
    document.body.style.overflow = "hidden";
  }

  function saveOutlineEdits() {
    if (!ui.outlineData) return;
    const current = ui.outlineData.outlines[ui.selectedOutlineIndex];
    if (!current) return;
    const title = document.querySelector('[data-outline-field="title"]');
    const thesis = document.querySelector('[data-outline-field="thesis"]');
    const question = document.querySelector('[data-outline-field="central_question"]');
    if (title) current.title = title.value.trim();
    if (thesis) current.thesis = thesis.value.trim();
    if (question) current.central_question = question.value.trim();
    document.querySelectorAll("[data-outline-section]").forEach((row) => {
      const i = Number(row.dataset.outlineSection);
      if (!current.sections[i]) return;
      const get = (name) => row.querySelector(`[data-section-field="${name}"]`);
      const titleEl = get("title");
      const goalEl = get("goal");
      const pointsEl = get("points");
      if (titleEl) current.sections[i].title = titleEl.value.trim();
      if (goalEl) current.sections[i].goal = goalEl.value.trim();
      if (pointsEl) current.sections[i].key_points = pointsEl.value.split(/\n/).map((x) => x.trim()).filter(Boolean);
    });
  }

  function selectOutline(index) {
    saveOutlineEdits();
    ui.selectedOutlineIndex = index;
    renderOutlineModal();
  }

  function backToTitles() {
    saveOutlineEdits();
    const current = ui.outlineData && ui.outlineData.outlines[ui.selectedOutlineIndex];
    if (current && ui.titleData && ui.titleData.titles[ui.selectedTitleIndex]) {
      ui.titleData.titles[ui.selectedTitleIndex].title = current.title;
    }
    renderTitleModal();
  }

  function startFromOutline() {
    saveOutlineEdits();
    const current = ui.outlineData && ui.outlineData.outlines[ui.selectedOutlineIndex];
    if (!current || !current.sections.length) {
      toast("这份大纲还没有内容");
      return;
    }
    ui.draft.selectedTitle = current.title || (ui.titleData && ui.titleData.titles[ui.selectedTitleIndex].title) || "";
    ui.draft.selectedOutline = deepClone(current);
    closeWorkflow();
    runGeneration();
  }

  async function runGeneration() {
    const d = ui.draft;
    if (!d) return;
    if (!validateDraftForGeneration()) return;
    const payload = Object.assign(basePayload(), {
      selectedTitle: d.selectedTitle || "",
      selectedOutline: d.selectedOutline || null
    });
    ui.lastPayload = payload;
    showGeneration();
    const started = Date.now();
    ui.genTimer = setInterval(() => {
      const el = document.getElementById("gen-status");
      if (el) el.textContent = `已用 ${Math.round((Date.now() - started) / 1000)}s`;
    }, 1000);

    const controller = new AbortController();
    ui.genAbort = controller;
    let finished = false;

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: controller.signal
      });

      if (!response.ok) {
        const raw = await response.text();
        let message = raw;
        try { message = JSON.parse(raw).error || raw; } catch (e) { /* ignore */ }
        throw new Error(message || "生成服务返回错误。");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let split;
        while ((split = buffer.indexOf("\n\n")) >= 0) {
          const block = buffer.slice(0, split);
          buffer = buffer.slice(split + 2);
          const evt = parseSSE(block);
          if (!evt) continue;
          if (evt.event === "error") throw new Error(evt.data.message || "生成失败。");
          if (evt.event === "done") {
            finished = true;
            finishGeneration(evt.data.project);
            return;
          }
          handleGenEvent(evt.event, evt.data);
        }
      }
      if (!finished) throw new Error("生成连接中断，请重试。");
    } catch (err) {
      if (err.name === "AbortError") return;
      showGenError(err.message || "生成失败，请重试。");
    } finally {
      if (ui.genTimer) {
        clearInterval(ui.genTimer);
        ui.genTimer = null;
      }
    }
  }

  /* ---------------- fixes & actions ---------------- */

  function removeParagraphByQuote(project, quote) {
    const key = quote.slice(0, 12);
    for (const section of project.sections) {
      const idx = section.paragraphs.findIndex((p) => p.includes(key));
      if (idx >= 0) {
        section.paragraphs.splice(idx, 1);
        return true;
      }
    }
    return false;
  }

  function findParagraphByQuote(project, quote) {
    const key = quote.slice(0, 12);
    for (let si = 0; si < project.sections.length; si++) {
      const section = project.sections[si];
      const pi = section.paragraphs.findIndex((p) => p.includes(key));
      if (pi >= 0) return { sectionIndex: si, paragraphIndex: pi, section, paragraph: section.paragraphs[pi] };
    }
    return null;
  }

  function closeRewriteModal() {
    overlayEl.innerHTML = "";
    document.body.style.overflow = "";
  }

  function showRewriteModal(id) {
    const route = getRoute();
    const project = getProject(route.id) || currentReviewProject();
    const issue = project && project.review && project.review.issues
      ? project.review.issues.find((i) => i.id === id)
      : null;
    if (!issue) return;
    overlayEl.innerHTML = `<div class="rewrite-shade" data-action="close-rewrite"></div>
      <div class="rewrite-modal" role="dialog" aria-label="修改建议">
        <p class="eyebrow">修改建议</p>
        <h3>${esc(issue.type)}</h3>
        <blockquote class="rewrite-quote">${esc(issue.quote)}</blockquote>
        <label class="rewrite-label" for="rewrite-instruction">修改建议（可编辑）</label>
        <textarea class="textarea rewrite-input" id="rewrite-instruction" placeholder="写下你希望这一段怎么改">${esc(issue.suggestion)}</textarea>
        <div class="rewrite-actions">
          <button class="btn ghost" data-action="close-rewrite">取消</button>
          <button class="btn primary" data-action="apply-rewrite" data-id="${issue.id}">按这个建议重写 ${icon("arrowRight")}</button>
        </div>
      </div>`;
    document.body.style.overflow = "hidden";
  }

  async function fixIssue(id, buttonEl, customSuggestion) {
    const route = getRoute();
    const project = getProject(route.id) || currentReviewProject();
    const issue = project && project.review && project.review.issues
      ? project.review.issues.find((i) => i.id === id)
      : null;
    if (!project || !issue) return;
    if (issue.resolved) return;

    if (buttonEl) {
      buttonEl.disabled = true;
      buttonEl.textContent = issue.fix === "fact" ? "核实中…" : "重写中…";
    }

    try {
      if (issue.fix === "fact") {
        // 旧示例稿的电池口径；真实生成稿只做人工核实标记。
        if (project.sample) {
          project.sections.forEach((s) => {
            s.paragraphs = s.paragraphs.map((p) => p.replace(/500mAh/g, "300mAh"));
          });
        }
        issue.resolved = true;
        project.updatedAt = nowISO();
        saveState();
        const y = window.scrollY;
        render(true);
        window.scrollTo(0, y);
        toast("已标记为人工核实。发布前请确认原始来源。");
        return;
      }

      if (issue.fix === "remove") {
        removeParagraphByQuote(project, issue.quote);
        issue.resolved = true;
        project.updatedAt = nowISO();
        saveState();
        const y = window.scrollY;
        render(true);
        window.scrollTo(0, y);
        toast("已按建议删掉这一段，评分已更新");
        return;
      }

      if (issue.fix === "rewrite") {
        const target = findParagraphByQuote(project, issue.quote);
        if (!target) {
          issue.resolved = true;
          saveState();
          render(true);
          toast("没有定位到原段落，已标记为已处理");
          return;
        }
        toast("正在按建议重写这一段…", 1600);
        const response = await fetch("/api/fix", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            personaId: project.personaId,
            persona: getPersona(project.personaId),
            title: project.title,
            sectionTitle: target.section.title,
            paragraph: target.paragraph,
            issue: {
              type: issue.type,
              evidence: issue.evidence,
              suggestion: String(customSuggestion || "").trim() || issue.suggestion
            },
            banned: state.settings.bannedPhrases || []
          })
        });
        const raw = await response.text();
        let data = {};
        try { data = JSON.parse(raw); } catch (e) { /* ignore */ }
        if (!response.ok) throw new Error(data.error || raw || "重写失败");
        if (!data.paragraph) throw new Error("模型没有返回新段落");

        target.section.paragraphs[target.paragraphIndex] = data.paragraph;
        issue.resolved = true;
        project.updatedAt = nowISO();
        saveState();
        const y = window.scrollY;
        render(true);
        window.scrollTo(0, y);
        toast("这一段已按建议重写，评分已更新");
        return;
      }

      issue.resolved = true;
      project.updatedAt = nowISO();
      saveState();
      const y = window.scrollY;
      render(true);
      window.scrollTo(0, y);
      toast("已标记为已处理");
    } catch (err) {
      toast(`处理失败：${err.message || "请稍后重试"}`, 3600);
      if (buttonEl) {
        buttonEl.disabled = false;
        buttonEl.textContent = issue.fix === "fact" ? "标记已核实" : "按建议重写";
      }
    }
  }

  function findHints(text) {
    return AI_HINTS.filter((x) => text.includes(x));
  }

  function findStrongHints(text) {
    return AI_HINTS.filter((x) => x.length >= 4 && text.includes(x));
  }

  function markIssuesResolvedByText(project, text) {
    if (!project.review || !project.review.issues) return;
    project.review.issues.forEach((issue) => {
      if (!issue.resolved && issue.quote && !text.includes(issue.quote)) issue.resolved = true;
    });
  }

  async function polishCurrentSection(buttonEl) {
    const route = getRoute();
    const project = getProject(route.id) || state.projects[0];
    if (!project) return;
    const sectionIndex = clamp(ui.activeSection || 0, 0, project.sections.length - 1);
    const section = project.sections[sectionIndex];
    const saved = ui.lastSelection;
    const useSelection = !!(saved && saved.text && saved.text.trim().length > 4 &&
      project.sections[saved.section] && project.sections[saved.section].paragraphs[saved.index] != null);
    const original = useSelection
      ? project.sections[saved.section].paragraphs[saved.index]
      : section.paragraphs.join("\n\n");
    if (!original.trim()) return;

    if (buttonEl) {
      buttonEl.disabled = true;
      buttonEl.textContent = "润色中…";
    }

    try {
      const response = await fetch("/api/polish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          personaId: project.personaId,
          persona: getPersona(project.personaId),
          text: original,
          context: section.title,
          highlight: useSelection ? saved.text : "",
          mode: useSelection ? "selection" : "section",
          banned: state.settings.bannedPhrases || []
        })
      });
      const raw = await response.text();
      let data = {};
      try { data = JSON.parse(raw); } catch (e) { /* ignore */ }
      if (!response.ok) throw new Error(data.error || raw || "润色失败");
      if (!data.text) throw new Error("模型没有返回润色结果");

      if (useSelection) {
        const target = project.sections[saved.section];
        target.paragraphs[saved.index] = data.text.trim();
        markIssuesResolvedByText(project, target.paragraphs.join("\n"));
        ui.lastSelection = null;
      } else {
        const parts = data.text.split(/\n{2,}/).map((x) => x.trim()).filter(Boolean);
        if (!parts.length) throw new Error("润色结果为空");
        section.paragraphs = parts;
        markIssuesResolvedByText(project, section.paragraphs.join("\n"));
      }
      project.updatedAt = nowISO();
      saveState();
      const y = window.scrollY;
      render(true);
      window.scrollTo(0, y);
      toast(useSelection ? "已重写你选中的段落，评分已更新" : "本节已重写，评分已更新");
      return;
    } catch (err) {
      // 服务端不可用时，退回本地硬规则；至少不让用户看到“没有明显模板句”
      const hints = findStrongHints(original);
      if (!useSelection && hints.length) {
        const filtered = section.paragraphs.filter((p) => findStrongHints(p).length === 0);
        if (filtered.length !== section.paragraphs.length) {
          section.paragraphs = filtered;
          markIssuesResolvedByText(project, section.paragraphs.join("\n"));
          project.updatedAt = nowISO();
          saveState();
          render(true);
          toast(`模型暂时不可用，已删掉 ${hints.length} 处明显模板表达`);
          return;
        }
      }
      toast(`润色失败：${err.message || "请稍后重试"}`, 3600);
      if (buttonEl) {
        buttonEl.disabled = false;
        buttonEl.textContent = "润色本节";
      }
    }
  }

  function openReview() {
    const route = getRoute();
    const project = getProject(route.id) || state.projects[0];
    if (!project) return;
    if (!project.review || !project.review.scores || !project.review.scores.persona) {
      project.review = {
        scores: { persona: 84, style: 80, content: 82, human: 76 },
        summary: "自检完成：整体稳定，未发现 high 级问题。",
        issues: []
      };
      saveState();
    }
    if (project.status === "draft") {
      project.status = "review";
      project.updatedAt = nowISO();
      saveState();
    }
    location.hash = `#/review/${project.id}`;
  }

  function publishProject() {
    const route = getRoute();
    const project = getProject(route.id) || currentReviewProject();
    if (!project) return;
    const high = unresolvedIssues(project).filter((i) => i.severity === "high");
    if (high.length) {
      toast(`还有 ${high.length} 处 high 级问题，先处理再发布`);
      return;
    }
    const passScore = Math.round(Number(state.settings.passThreshold || 0.9) * 100);
    const score = projectScore(project) || 0;
    if (score < passScore) {
      toast(`当前 ${score} 分，低于通过线 ${passScore} 分。再改一轮。`);
      return;
    }
    project.status = "published";
    project.updatedAt = nowISO();
    saveState();
    location.hash = "#/";
    setTimeout(() => toast("已发布。下一步可以接入公众号草稿箱。"), 300);
  }

  function exportProjectData(project) {
    if (!project) return;
    const text = `# ${project.title}\n\n` +
      project.sections.map((s) => `## ${s.title}\n\n${s.paragraphs.join("\n\n")}`).join("\n\n");
    download(`${project.title}.md`, text, "text/markdown;charset=utf-8");
    toast("已导出 Markdown");
  }

  function exportProject() {
    const route = getRoute();
    exportProjectData(getProject(route.id) || activeProjects()[0]);
  }

  function duplicateProject(id) {
    const source = getProject(id);
    if (!source) return;
    const copy = deepClone(source);
    copy.id = "p-" + Date.now();
    copy.title = source.title + "（副本）";
    copy.status = "draft";
    copy.trashed = false;
    delete copy.trashedAt;
    copy.updatedAt = nowISO();
    copy.createdAt = nowISO();
    copy.version = 1;
    delete copy.sample;
    state.projects.unshift(copy);
    saveState();
    closeProjectMenu();
    location.hash = `#/studio/${copy.id}`;
    toast("已复制一份");
  }

  function moveProjectToTrash(id) {
    const project = getProject(id);
    if (!project) return;
    project.trashed = true;
    project.trashedAt = nowISO();
    saveState();
    closeProjectMenu();
    const route = getRoute();
    if ((route.name === "studio" || route.name === "review") && route.id === id) location.hash = "#/";
    else render();
    toast("已移入回收站");
  }

  function restoreProject(id) {
    const project = getProject(id);
    if (!project) return;
    project.trashed = false;
    delete project.trashedAt;
    saveState();
    render();
    toast("已恢复");
  }

  function purgeProject(id) {
    const project = getProject(id);
    if (!project) return;
    if (!confirm(`彻底删除《${project.title}》？删除后无法恢复。`)) return;
    state.projects = state.projects.filter((p) => p.id !== id);
    saveState();
    render();
    toast("已彻底删除");
  }

  function clearTrash() {
    const count = trashedProjects().length;
    if (!count) return;
    if (!confirm(`清空回收站里的 ${count} 篇文章？删除后无法恢复。`)) return;
    state.projects = activeProjects();
    saveState();
    render();
    toast("回收站已清空");
  }

  function toggleProjectStatus(id) {
    const project = getProject(id);
    if (!project) return;
    project.status = project.status === "published" ? "review" : "published";
    project.updatedAt = nowISO();
    saveState();
    closeProjectMenu();
    render();
    toast(project.status === "published" ? "已标记为已发布" : "已转为待评审");
  }

  function closeProjectMenu() {
    overlayEl.innerHTML = "";
  }

  function showProjectMenu(id, button) {
    const project = getProject(id);
    if (!project || !button) return;
    const rect = button.getBoundingClientRect();
    const width = 190;
    const left = Math.max(8, Math.min(rect.right - width, window.innerWidth - width - 8));
    const top = Math.max(8, Math.min(rect.bottom + 6, window.innerHeight - 278));
    const published = project.status === "published";
    overlayEl.innerHTML = `<div class="project-menu-shade" data-action="close-project-menu"></div>
      <div class="project-menu" style="left:${left}px;top:${top}px" role="menu">
        <button class="project-menu-item" data-action="project-duplicate" data-id="${project.id}" role="menuitem">${icon("copy")} 复制一份</button>
        <button class="project-menu-item" data-action="project-edit" data-id="${project.id}" role="menuitem">${icon("pen")} 编辑</button>
        <button class="project-menu-item" data-action="project-export" data-id="${project.id}" role="menuitem">${icon("download")} 导出 Markdown</button>
        <button class="project-menu-item" data-action="project-toggle-status" data-id="${project.id}" role="menuitem">${icon("check")} ${published ? "转为待评审" : "标记为已发布"}</button>
        <button class="project-menu-item danger" data-action="project-delete" data-id="${project.id}" role="menuitem">${icon("trash")} 删除</button>
      </div>`;
  }

  function exportAll() {
    download("tuibenbang-data.json", JSON.stringify(state, null, 2), "application/json");
    toast("已导出全部数据");
  }

  function resetData() {
    if (!confirm("恢复示例数据会清空本地修改，确定吗？")) return;
    try { localStorage.removeItem(STORE_KEY); } catch (e) { /* ignore */ }
    state = loadState();
    ui.draft = null;
    ui.activeSection = 0;
    applyTheme();
    applyReading();
    location.hash = "#/";
    render(true);
    toast("已恢复示例数据");
  }

  /* ---------------- render ---------------- */

  function showAccountPopup() {
    if (!authUser) return;
    overlayEl.innerHTML = `<div class="account-shade" data-action="close-account"></div>
      <aside class="account-pop" role="dialog" aria-label="账户">
        <div class="account-head">
          ${personaAvatar({ initial: (authUser.name || authUser.account || "写").slice(0, 1), accent: "#B4452A" })}
          <div><b>${esc(authUser.name || "写作者")}</b><span>${esc(authUser.account)}</span></div>
          <button class="icon-btn" data-action="close-account" aria-label="关闭">${icon("close")}</button>
        </div>
        <form class="account-form" data-form="profile">
          <label>昵称</label>
          <div class="account-inline"><input name="name" value="${esc(authUser.name || "")}" /><button class="btn tiny" type="submit">保存</button></div>
        </form>
        <form class="account-form" data-form="account">
          <label>更换账号</label>
          <div class="account-inline"><input name="account" value="${esc(authUser.account)}" /><button class="btn tiny" type="submit">更换</button></div>
        </form>
        <form class="account-form" data-form="password">
          <label>修改密码</label>
          <input name="oldPassword" type="password" placeholder="原密码" autocomplete="current-password" />
          <div class="account-inline"><input name="newPassword" type="password" placeholder="新密码，至少 6 位" autocomplete="new-password" /><button class="btn tiny" type="submit">修改</button></div>
        </form>
        <div class="account-actions">
          <button class="btn small ghost" data-action="logout">退出登录</button>
        </div>
      </aside>`;
    document.body.style.overflow = "hidden";
  }

  function closeAccountPopup() {
    overlayEl.innerHTML = "";
    document.body.style.overflow = "";
  }

  async function logout() {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } catch (e) { /* ignore */ }
    authUser = null;
    ui.draft = null;
    clearGeneration();
    closeAccountPopup();
    renderLogin();
    toast("已退出登录");
  }

  function render(keepScroll) {
    if (!authUser) {
      renderLogin();
      return;
    }
    const route = getRoute();
    const y = window.scrollY;
    let result;

    switch (route.name) {
      case "home":
        result = { html: homePage(), crumb: "工作台", title: "工作台", pageClass: "" };
        break;
      case "new":
        result = { html: newPage(route), crumb: "新建推文", title: "新建推文", pageClass: "" };
        break;
      case "works":
        result = { html: worksPage(route), crumb: "稿件", title: "稿件", pageClass: "" };
        break;
      case "trash":
        result = { html: trashPage(route), crumb: "回收站", title: "回收站", pageClass: "" };
        break;
      case "studio": {
        const p = getProject(route.id) || state.projects[0];
        result = { html: studioPage(route), crumb: p ? p.title : "写作台", title: p ? p.title : "写作台", pageClass: "page-studio" };
        break;
      }
      case "review": {
        const p = getProject(route.id) || currentReviewProject();
        result = { html: reviewPage(route), crumb: "自检报告", title: "自检报告", pageClass: "" };
        break;
      }
      case "personas":
        result = { html: personasPage(), crumb: "人设库", title: "人设库", pageClass: "" };
        break;
      case "persona": {
        if (route.id === "new" || (route.parts && route.parts[2] === "edit")) {
          const p = route.id === "new" ? null : state.personas.find((x) => x.id === route.id);
          result = { html: personaEditPage(route), crumb: route.id === "new" ? "新建人设" : "编辑人设", title: route.id === "new" ? "新建人设" : `编辑 ${p ? p.name : "人设"}`, pageClass: "" };
        } else {
          const p = state.personas.find((x) => x.id === route.id);
          result = { html: personaPage(route), crumb: p ? p.name : "人设", title: p ? p.name : "人设", pageClass: "" };
        }
        break;
      }
      case "settings":
        result = { html: settingsPage(), crumb: "设置", title: "设置", pageClass: "" };
        break;
      default:
        result = { html: notFoundPage(), crumb: "404", title: "404", pageClass: "" };
    }

    app.innerHTML = shell(result.html, route, result);
    document.title = `${result.title} · 推文帮`;
    applyReading();
    if (!keepScroll) window.scrollTo(0, 0);
    else window.scrollTo(0, y);
    if (route.name === "settings") setTimeout(checkApiStatus, 30);
  }

  async function checkApiStatus() {
    const el = document.getElementById("api-status");
    if (!el) return;
    try {
      const response = await fetch("/api/health", { cache: "no-store" });
      const data = await response.json();
      if (data.configured) {
        el.textContent = `已连接 · ${data.model}`;
        el.style.color = "var(--sage)";
      } else {
        el.textContent = "未配置模型密钥";
        el.style.color = "var(--danger)";
      }
    } catch (err) {
      el.textContent = "未连接本地服务";
      el.style.color = "var(--danger)";
    }
  }

  /* ---------------- events ---------------- */

  function updatePerspectiveHint(button) {
    if (!button) return;
    const hint = document.getElementById("perspective-hint");
    if (hint && button.dataset.hint) hint.textContent = button.dataset.hint;
  }

  document.addEventListener("pointerover", (e) => {
    const btn = e.target.closest && e.target.closest('[data-action="pick-perspective"]');
    if (btn) updatePerspectiveHint(btn);
  });

  document.addEventListener("focusin", (e) => {
    const btn = e.target.closest && e.target.closest('[data-action="pick-perspective"]');
    if (btn) updatePerspectiveHint(btn);
  });

  document.addEventListener("click", async (e) => {
    const actionEl = e.target.closest("[data-action]");
    if (!actionEl) return;
    const action = actionEl.dataset.action;

    switch (action) {
      case "toggle-theme":
        toggleTheme();
        break;
      case "go-back":
        if (window.history.length > 1) window.history.back();
        else location.hash = "#/";
        break;
      case "toggle-theme-login": {
        const next = resolvedTheme() === "dark" ? "light" : "dark";
        state.theme = next;
        saveState();
        applyTheme();
        const btn = document.getElementById("auth-theme");
        if (btn) btn.innerHTML = icon(next === "dark" ? "sun" : "moon");
        break;
      }
      case "auth-type":
        ui.authType = actionEl.dataset.type;
        authError("");
        renderLogin();
        break;
      case "auth-mode":
        ui.authMode = actionEl.dataset.mode;
        authError("");
        renderLogin();
        break;
      case "account-pop":
        showAccountPopup();
        break;
      case "close-account":
        closeAccountPopup();
        break;
      case "logout":
        logout();
        break;
      case "set-theme":
        setTheme(actionEl.dataset.value);
        break;
      case "set-reading":
        state.settings.reading = actionEl.dataset.value;
        saveState();
        applyReading();
        render(true);
        break;
      case "set-font": {
        const scale = { small: 0.95, normal: 1.04, large: 1.12 }[actionEl.dataset.value] || 1.04;
        state.settings.fontScale = scale;
        saveState();
        applyReading();
        render(true);
        break;
      }
      case "analyze-persona":
        analyzePersona(actionEl);
        break;
      case "save-banned": {
        const input = document.getElementById("banned-input");
        state.settings.bannedPhrases = String(input ? input.value : "").split(/\n|,|，/).map((x) => x.trim()).filter(Boolean);
        state.settings.bannedExpanded = true;
        state.settings.bannedVersion = SEED.settings.bannedVersion || 2;
        saveState();
        toast("写作规则已保存");
        break;
      }
      case "wizard-step":
        ui.step = Number(actionEl.dataset.step);
        ui.draft.step = ui.step;
        render();
        break;
      case "wizard-next":
        if (ui.step === 2 && !(ui.draft.topic || "").trim()) {
          toast("先给一个主题，再往下走");
          const ta = document.getElementById("topic");
          if (ta) ta.focus();
          return;
        }
        if (ui.step < 3) {
          ui.step += 1;
          ui.draft.step = ui.step;
          render();
        }
        break;
      case "wizard-back":
        if (ui.step > 1) {
          ui.step -= 1;
          ui.draft.step = ui.step;
          render();
        }
        break;
      case "pick-persona":
        ui.draft.personaId = actionEl.dataset.id;
        render(true);
        break;
      case "pick-audience":
        ui.draft.audience = actionEl.dataset.value;
        render(true);
        break;
      case "pick-format":
        ui.draft.format = actionEl.dataset.value;
        render(true);
        break;
      case "pick-advice":
        ui.draft.includeAdvice = actionEl.dataset.value === "1";
        render(true);
        break;
      case "pick-length":
        ui.draft.length = Number(actionEl.dataset.value);
        render(true);
        break;
      case "pick-pace":
        ui.draft.pace = actionEl.dataset.value;
        render(true);
        break;
      case "pick-perspective":
        ui.draft.perspective = actionEl.dataset.value;
        render(true);
        break;
      case "remove-attachment":
        ui.draft.attachments = (ui.draft.attachments || []).filter((_, i) => i !== Number(actionEl.dataset.index));
        render(true);
        break;
      case "generate":
        openTitlePicker();
        break;
      case "close-generation":
        clearGeneration();
        break;
      case "retry-generation":
        clearGeneration();
        setTimeout(() => runGeneration(), 180);
        break;
      case "jump-section": {
        const idx = Number(actionEl.dataset.index);
        ui.activeSection = idx;
        const el = document.getElementById(`section-${idx}`);
        if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
        document.querySelectorAll(".outline-item").forEach((x) => x.classList.remove("active"));
        actionEl.classList.add("active");
        break;
      }
      case "polish-section":
        await polishCurrentSection(actionEl);
        break;
      case "open-review":
        openReview();
        break;
      case "save-project":
        saveState();
        toast("已保存到本地");
        break;
      case "export-project":
        exportProject();
        break;
      case "project-menu":
        showProjectMenu(actionEl.dataset.id, actionEl);
        break;
      case "close-project-menu":
        closeProjectMenu();
        break;
      case "project-duplicate":
        duplicateProject(actionEl.dataset.id);
        break;
      case "project-edit":
        closeProjectMenu();
        location.hash = "#/studio/" + actionEl.dataset.id;
        break;
      case "project-export":
        exportProjectData(getProject(actionEl.dataset.id));
        closeProjectMenu();
        break;
      case "project-toggle-status":
        toggleProjectStatus(actionEl.dataset.id);
        break;
      case "project-delete":
        moveProjectToTrash(actionEl.dataset.id);
        break;
      case "restore-project":
        restoreProject(actionEl.dataset.id);
        break;
      case "purge-project":
        purgeProject(actionEl.dataset.id);
        break;
      case "clear-trash":
        clearTrash();
        break;
      case "fix-issue": {
        const route = getRoute();
        const project = getProject(route.id) || currentReviewProject();
        const issue = project && project.review && project.review.issues
          ? project.review.issues.find((i) => i.id === actionEl.dataset.id)
          : null;
        if (issue && issue.fix === "rewrite") showRewriteModal(issue.id);
        else await fixIssue(actionEl.dataset.id, actionEl);
        break;
      }
      case "close-rewrite":
        closeRewriteModal();
        break;
      case "apply-rewrite": {
        const input = document.getElementById("rewrite-instruction");
        const custom = input ? input.value : "";
        closeRewriteModal();
        await fixIssue(actionEl.dataset.id, null, custom);
        break;
      }
      case "workflow-close":
        closeWorkflow();
        break;
      case "workflow-refresh-titles":
        openTitlePicker();
        break;
      case "workflow-generate-outlines":
        generateOutlines();
        break;
      case "workflow-select-outline":
        selectOutline(Number(actionEl.dataset.index));
        break;
      case "workflow-back-titles":
        backToTitles();
        break;
      case "workflow-refresh-outlines":
        if (ui.outlineData) {
          saveOutlineEdits();
          const current = ui.outlineData.outlines[ui.selectedOutlineIndex];
          if (current && ui.titleData) {
            ui.titleData.titles[ui.selectedTitleIndex] = Object.assign({}, ui.titleData.titles[ui.selectedTitleIndex], { title: current.title });
          }
          generateOutlines();
        }
        break;
      case "workflow-start":
        startFromOutline();
        break;
      case "run-check": {
        const route = getRoute();
        const p = getProject(route.id) || currentReviewProject();
        if (!p) return;
        if (!p.review.issues.length) {
          toast("自检完成：没有发现明显问题");
        } else {
          toast(`自检完成：${overallScore(metricsFor(p))} 分，${unresolvedIssues(p).length} 项待处理`);
        }
        break;
      }
      case "publish-project":
        publishProject();
        break;
      case "export-data":
        exportAll();
        break;
      case "reset-data":
        resetData();
        break;
      case "delete-persona": {
        const id = actionEl.dataset.id;
        if (state.personas.length <= 1) {
          toast("至少保留一个人设");
          return;
        }
        if (!confirm("删除人设后不可恢复，确定吗？")) return;
        state.personas = state.personas.filter((p) => p.id !== id);
        const fallback = state.personas[0].id;
        state.projects.forEach((p) => { if (p.personaId === id) p.personaId = fallback; });
        saveState();
        location.hash = "#/personas";
        render();
        toast("人设已删除");
        break;
      }
      default:
        break;
    }
  });

  async function analyzePersona(buttonEl) {
    const samples = document.getElementById("p-samples");
    const text = (samples ? samples.value : "").trim();
    const status = document.getElementById("analyze-status");
    if (text.length < 80) {
      toast("至少贴 80 字样稿");
      return;
    }
    if (buttonEl) { buttonEl.disabled = true; buttonEl.textContent = "分析中…"; }
    if (status) status.textContent = "正在读样稿…";
    try {
      const response = await fetch("/api/persona/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "分析失败");
      const set = (id, value) => { const el = document.getElementById(id); if (el && value != null) el.value = value; };
      set("p-cat", data.category || "");
      set("p-role", data.role || "");
      set("p-bio", data.bio || "");
      set("p-L", (data.anchors || []).join("\n"));
      set("p-word", (data.style && data.style.word || []).join("\n"));
      set("p-sentence", (data.style && data.style.sentence || []).join("\n"));
      set("p-discourse", (data.style && data.style.discourse || []).join("\n"));
      const mm = document.querySelector('[name="mMeaning"]');
      const ms = document.querySelector('[name="mStrain"]');
      const sv = document.querySelector('[name="sVal"]');
      if (mm) mm.value = data.M && data.M.meaning != null ? data.M.meaning : 5;
      if (ms) ms.value = data.M && data.M.strain != null ? data.M.strain : 5;
      if (sv) sv.value = data.S != null ? data.S : 5;
      if (status) status.textContent = "已填写，检查后保存";
      toast("风格已分析，检查后保存");
    } catch (err) {
      if (status) status.textContent = "";
      toast(err.message || "分析失败");
    } finally {
      if (buttonEl) { buttonEl.disabled = false; buttonEl.textContent = "分析并填写"; }
    }
  }

  function savePersonaForm(form) {
    const fd = new FormData(form);
    const name = String(fd.get("name") || "").trim();
    const role = String(fd.get("role") || "").trim();
    if (!name || !role) {
      toast("名字和身份至少要填一个");
      return;
    }
    const lines = (key) => String(fd.get(key) || "").split(/\n|；|;/).map((x) => x.trim()).filter(Boolean);
    const existingId = form.dataset.personaId;
    const existing = state.personas.find((p) => p.id === existingId);
    const id = existing ? existing.id : "p-" + Date.now();
    const persona = {
      id,
      name,
      initial: name.slice(0, 1),
      category: String(fd.get("category") || "通用").trim() || "通用",
      role,
      tagline: existing ? (existing.tagline || "") : "",
      bio: String(fd.get("bio") || "").trim(),
      accent: String(fd.get("accent") || "#B4452A"),
      L: lines("L"),
      style: {
        word: lines("word"),
        sentence: lines("sentence"),
        discourse: lines("discourse")
      },
      anti: [],
      M: {
        meaning: clamp(Number(fd.get("mMeaning")) || 5, 0, 10),
        strain: clamp(Number(fd.get("mStrain")) || 5, 0, 10)
      },
      S: clamp(Number(fd.get("sVal")) || 5, 0, 10),
      sample: existing ? (existing.sample || "") : ""
    };
    if (existing) {
      state.personas = state.personas.map((p) => p.id === id ? persona : p);
    } else {
      state.personas.unshift(persona);
    }
    saveState();
    location.hash = `#/persona/${id}`;
    toast(existing ? "人设已更新" : "人设已创建");
  }

  async function handleAuthSubmit(form) {
    const fd = new FormData(form);
    const account = String(fd.get("account") || "").trim();
    const password = String(fd.get("password") || "");
    const confirm = String(fd.get("confirm") || "");
    const register = ui.authMode === "register";
    if (register && password !== confirm) {
      authError("两次输入的密码不一致");
      return;
    }
    authError("");
    const button = form.querySelector(".auth-submit");
    if (button) { button.disabled = true; button.textContent = register ? "创建中…" : "登录中…"; }
    try {
      const response = await fetch(`/api/auth/${register ? "register" : "login"}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ account, password, name: String(fd.get("name") || "").trim() })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "登录失败");
      authUser = data.user;
      ui.authMode = "login";
      ui.captcha = false;
      ui.captchaProgress = 0;
      render();
      toast(register ? "账户已创建" : "已登录");
    } catch (err) {
      authError(err.message || "登录失败，稍后重试");
      if (button) { button.disabled = false; button.textContent = register ? "创建并登录" : "登录"; }
    }
  }

  function readImageFiles(files) {
    const list = Array.from(files || []).filter((f) => f.type.startsWith("image/"));
    if (!list.length) return;
    const room = 4 - (ui.draft.attachments || []).length;
    if (room <= 0) {
      toast("最多放 4 张图片");
      return;
    }
    list.slice(0, room).forEach((file) => {
      if (file.size > 2 * 1024 * 1024) {
        toast(`${file.name} 超过 2MB，已跳过`);
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        ui.draft.attachments = ui.draft.attachments || [];
        ui.draft.attachments.push({ name: file.name, dataUrl: String(reader.result) });
        if (getRoute().name === "new") render(true);
      };
      reader.readAsDataURL(file);
    });
  }

  document.addEventListener("change", (e) => {
    if (e.target.matches("#image-input")) {
      readImageFiles(e.target.files);
      e.target.value = "";
    }
  });

  document.addEventListener("dragover", (e) => {
    const zone = e.target.closest("[data-dropzone]");
    if (!zone) return;
    e.preventDefault();
    zone.classList.add("dragging");
  });

  document.addEventListener("dragleave", (e) => {
    const zone = e.target.closest("[data-dropzone]");
    if (!zone) return;
    zone.classList.remove("dragging");
  });

  document.addEventListener("drop", (e) => {
    const zone = e.target.closest("[data-dropzone]");
    if (!zone) return;
    e.preventDefault();
    zone.classList.remove("dragging");
    readImageFiles(e.dataTransfer.files);
  });

  document.addEventListener("change", (e) => {
    if (e.target.matches('input[name="workflow-title"]')) {
      ui.selectedTitleIndex = Number(e.target.value);
      document.querySelectorAll(".title-choice").forEach((el, i) => el.classList.toggle("active", i === ui.selectedTitleIndex));
    }
  });

  document.addEventListener("input", (e) => {
    if (e.target.matches("[data-title-index]") && ui.titleData) {
      const i = Number(e.target.dataset.titleIndex);
      if (ui.titleData.titles[i]) ui.titleData.titles[i].title = e.target.value;
    }
  });

  document.addEventListener("selectionchange", () => {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || !sel.toString().trim()) return;
    let node = sel.anchorNode;
    if (node && node.nodeType === 3) node = node.parentElement;
    const para = node && node.closest ? node.closest('p[data-edit="paragraph"]') : null;
    if (para) {
      ui.lastSelection = {
        text: sel.toString().trim(),
        section: Number(para.dataset.section),
        index: Number(para.dataset.index)
      };
    }
  });

  document.addEventListener("pointerdown", (e) => {
    const handle = e.target.closest("[data-captcha-handle]");
    if (!handle || ui.captcha) return;
    const track = handle.closest("[data-captcha]");
    if (!track) return;
    e.preventDefault();
    const max = Math.max(1, track.clientWidth - handle.offsetWidth - 4);
    ui.captchaDrag = { startX: e.clientX, max, id: e.pointerId };
    handle.classList.add("dragging");
    if (handle.setPointerCapture) {
      try { handle.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    }
  });

  document.addEventListener("pointermove", (e) => {
    if (!ui.captchaDrag) return;
    const p = (e.clientX - ui.captchaDrag.startX) / ui.captchaDrag.max;
    updateCaptcha(clamp(p, 0, 1), false);
  });

  document.addEventListener("pointerup", (e) => {
    if (!ui.captchaDrag) return;
    const p = clamp((e.clientX - ui.captchaDrag.startX) / ui.captchaDrag.max, 0, 1);
    updateCaptcha(p >= 0.95 ? 1 : 0, p >= 0.95);
    const handle = document.querySelector("[data-captcha-handle]");
    if (handle) handle.classList.remove("dragging");
    ui.captchaDrag = null;
  });

  document.addEventListener("pointercancel", () => {
    if (!ui.captchaDrag) return;
    ui.captchaDrag = null;
    resetCaptcha();
  });

  document.addEventListener("submit", (e) => {
    const profileForm = e.target.closest('[data-form="profile"]');
    if (profileForm) {
      e.preventDefault();
      const name = String(new FormData(profileForm).get("name") || "").trim();
      fetch("/api/auth/profile", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name }) })
        .then(async (r) => { const d = await r.json(); if (!r.ok) throw new Error(d.error); authUser = d.user; closeAccountPopup(); render(true); toast("昵称已更新"); })
        .catch((err) => toast(err.message || "保存失败"));
      return;
    }
    const accountForm = e.target.closest('[data-form="account"]');
    if (accountForm) {
      e.preventDefault();
      const account = String(new FormData(accountForm).get("account") || "").trim();
      fetch("/api/auth/account", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ account }) })
        .then(async (r) => { const d = await r.json(); if (!r.ok) throw new Error(d.error); authUser = d.user; closeAccountPopup(); render(true); toast("登录账号已更换"); })
        .catch((err) => toast(err.message || "更换失败"));
      return;
    }
    const passwordForm = e.target.closest('[data-form="password"]');
    if (passwordForm) {
      e.preventDefault();
      const fd = new FormData(passwordForm);
      fetch("/api/auth/password", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ oldPassword: fd.get("oldPassword"), newPassword: fd.get("newPassword") }) })
        .then(async (r) => { const d = await r.json(); if (!r.ok) throw new Error(d.error); passwordForm.reset(); toast("密码已修改"); })
        .catch((err) => toast(err.message || "修改失败"));
      return;
    }
    const authForm = e.target.closest('[data-form="auth"]');
    if (authForm) {
      e.preventDefault();
      handleAuthSubmit(authForm);
      return;
    }
    const personaForm = e.target.closest('[data-form="persona"]');
    if (personaForm) {
      e.preventDefault();
      savePersonaForm(personaForm);
      return;
    }
    const form = e.target.closest('[data-form="quick"]');
    if (!form) return;
    e.preventDefault();
    const topic = (form.querySelector('[name="topic"]').value || "").trim();
    ui.draft = {
      personaId: form.querySelector('[name="persona"]').value,
      topic,
      product: "",
      notes: "",
      attachments: [],
      audience: "普通读者",
      customAudience: "",
      format: "深度长文",
      customFormat: "",
      includeAdvice: false,
      pace: "fast",
      perspective: "auto",
      length: 3000,
      tone: 3,
      step: topic ? 2 : 1
    };
    ui.step = topic ? 2 : 1;
    location.hash = "#/new";
    if (getRoute().name === "new") render();
  });

  document.addEventListener("input", (e) => {
    const el = e.target;
    if (el.matches('[data-field="topic"]')) {
      ui.draft.topic = el.value;
    }
    if (el.matches('[data-field="product"]')) {
      ui.draft.product = el.value;
    }
    if (el.matches('[data-field="notes"]')) {
      ui.draft.notes = el.value;
    }
    if (el.matches('[data-field="customFormat"]')) {
      ui.draft.customFormat = el.value;
    }
    if (el.matches('[data-field="customAudience"]')) {
      ui.draft.customAudience = el.value;
    }
    if (el.matches('[data-field="length"]')) {
      ui.draft.length = clamp(Number(el.value) || 3000, 500, 10000);
    }
    if (el.matches('[data-field="tone"]')) {
      ui.draft.tone = Number(el.value);
      const label = document.getElementById("tone-label");
      if (label) label.textContent = toneLabel(ui.draft.tone);
    }
    if (el.matches('[data-setting="pdsThreshold"]')) {
      state.settings.pdsThreshold = Number(el.value);
      const label = document.getElementById("pds-value");
      if (label) label.textContent = Number(el.value).toFixed(2);
      saveState();
    }
    if (el.matches('[data-setting="passThreshold"]')) {
      state.settings.passThreshold = Number(el.value);
      const label = document.getElementById("pass-value");
      if (label) label.textContent = Number(el.value).toFixed(2);
      saveState();
    }
  });

  document.addEventListener("focusout", (e) => {
    const el = e.target.closest("[data-edit]");
    if (!el) return;
    const route = getRoute();
    if (route.name !== "studio") return;
    const project = getProject(route.id) || state.projects[0];
    if (!project) return;
    const kind = el.dataset.edit;
    if (kind === "title") {
      project.title = el.textContent.trim();
      const crumb = document.querySelector(".crumb b");
      if (crumb) crumb.textContent = project.title;
    } else if (kind === "dek") {
      project.dek = el.textContent.trim();
    } else if (kind === "section-title") {
      const idx = Number(el.dataset.section);
      if (project.sections[idx]) project.sections[idx].title = el.textContent.trim();
    } else if (kind === "paragraph") {
      const idx = Number(el.dataset.section);
      const pi = Number(el.dataset.index);
      if (project.sections[idx] && project.sections[idx].paragraphs[pi] != null) {
        project.sections[idx].paragraphs[pi] = el.textContent.trim();
      }
    }
    project.updatedAt = nowISO();
    saveState();
  });

  document.addEventListener("input", (e) => {
    const el = e.target;
    if (el.matches('[data-edit="title"]')) {
      const route = getRoute();
      const project = getProject(route.id) || state.projects[0];
      if (project) {
        project.title = el.textContent.trim();
        project.updatedAt = nowISO();
        saveState();
        const crumb = document.querySelector(".crumb b");
        if (crumb) crumb.textContent = project.title;
      }
    }
  });

  // system theme changes
  if (window.matchMedia) {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => {
      if (themePref() === "system") {
        applyTheme();
        render(true);
      }
    };
    if (mq.addEventListener) mq.addEventListener("change", onChange);
    else if (mq.addListener) mq.addListener(onChange);
  }

  window.addEventListener("hashchange", () => {
    if (getRoute().params.get("fresh") === "1") ui.freshConsumed = false;
    render();
  });

  setInterval(refreshTimes, 30000);

  async function boot() {
    applyTheme();
    applyReading();
    if (!location.hash) {
      try { history.replaceState(null, "", "#/"); } catch (e) { /* ignore */ }
    }
    try {
      const response = await fetch("/api/auth/me", { cache: "no-store" });
      if (response.ok) {
        const data = await response.json();
        if (data.user) {
          authUser = data.user;
          render();
          return;
        }
      }
    } catch (e) { /* offline or not logged in */ }
    renderLogin();
  }

  boot();
})();
