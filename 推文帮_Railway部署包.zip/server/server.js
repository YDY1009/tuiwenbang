"use strict";

/**
 * 推文帮 · 本地服务端
 * - 静态托管 web/
 * - POST /api/generate  SSE：四段真实生成流水线
 * - POST /api/fix       按评审建议重写一段
 * - GET  /api/health    服务状态
 *
 * 模型：DeepSeek（默认 deepseek-chat）
 * 密钥：优先 DEEPSEEK_API_KEY 环境变量；否则读取 ~/.dsh/.credentials.yaml
 */

const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("os");
const vm = require("vm");
const crypto = require("crypto");

const ROOT = path.resolve(__dirname, "..");
const WEB = path.join(ROOT, "web");
const HOST = process.env.HOST || "127.0.0.1";
const PORT = Number(process.env.PORT || 4173);
const MODEL = process.env.DEEPSEEK_MODEL || "deepseek-chat";
const API_URL = process.env.DEEPSEEK_API_URL || "https://api.deepseek.com/chat/completions";

const USERS_DIR = path.join(__dirname, "data");
const USERS_FILE = path.join(USERS_DIR, "users.json");
const SESSION_COOKIE = "tb_session";
const SESSION_TTL = 7 * 24 * 60 * 60 * 1000;
const sessions = new Map();

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function loadSeed() {
  const code = fs.readFileSync(path.join(WEB, "data.js"), "utf8");
  const sandbox = { window: {} };
  vm.runInNewContext(code, sandbox, { timeout: 2000 });
  return sandbox.window.SEED;
}

const SEED = loadSeed();
const PERSONAS = Object.fromEntries(SEED.personas.map((p) => [p.id, p]));
const BANNED = (SEED.settings && SEED.settings.bannedPhrases) || [
  "先说结论",
  "综上所述",
  "值得注意的是",
  "总的来说"
];

// 从中文写作社区的高频吐槽里整理的 AI 模板句 / 腔调。
// 仅用于提示与评审，不直接全文替换，避免误伤正常表达。
const AI_TEMPLATE_PHRASES = [
  "先说结论", "先给结论", "先给判断", "一句话总结", "重点来了", "掰开揉碎",
  "综上所述", "总而言之", "归根结底", "说到底", "由此可见", "不难发现",
  "值得注意的是", "值得一提的是", "众所周知", "毋庸置疑", "不可否认",
  "在当今", "在这个", "随着", "让我们", "希望这篇文章", "希望以上",
  "核心逻辑是", "底层逻辑", "直击痛点", "重新定义", "直接封神", "炸裂",
  "干货满满", "保姆级", "一文读懂", "建议收藏", "划重点", "谁懂啊",
  "绝绝子", "狠狠", "姐妹们", "不要焦虑", "为你好", "你要相信",
  "重点来了", "掰开揉碎", "我们不妨", "不得不说", "天花板", "王炸", "必看", "封神",
  "第一年", "第二年", "第三年", "逐年",
  "重点来了", "掰开揉碎", "我们不妨", "不得不说", "天花板", "王炸", "必看", "封神",
  "第一年", "第二年", "第三年", "逐年",
  "不是……而是……", "不仅……而且……", "真正的……不是……而是……"
];

function readApiKey() {
  if (process.env.DEEPSEEK_API_KEY) return process.env.DEEPSEEK_API_KEY.trim();
  try {
    const file = path.join(os.homedir(), ".dsh", ".credentials.yaml");
    if (!fs.existsSync(file)) return "";
    const text = fs.readFileSync(file, "utf8");
    const match = text.match(/DEEPSEEK_API_KEY:\s*['"]?([^\s'",}]+)/);
    return match ? match[1] : "";
  } catch (err) {
    return "";
  }
}

const API_KEY = readApiKey();

function ensureUsersFile() {
  fs.mkdirSync(USERS_DIR, { recursive: true });
  if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, "[]", { mode: 0o600 });
}

function loadUsers() {
  ensureUsersFile();
  try {
    const raw = fs.readFileSync(USERS_FILE, "utf8");
    const list = JSON.parse(raw || "[]");
    return Array.isArray(list) ? list : [];
  } catch (err) {
    return [];
  }
}

function saveUsers(users) {
  ensureUsersFile();
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), { mode: 0o600 });
}

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString("hex");
}

function parseCookies(req) {
  const header = req.headers.cookie || "";
  const out = {};
  header.split(";").forEach((part) => {
    const idx = part.indexOf("=");
    if (idx < 0) return;
    out[part.slice(0, idx).trim()] = decodeURIComponent(part.slice(idx + 1).trim());
  });
  return out;
}

function currentUser(req) {
  const token = parseCookies(req)[SESSION_COOKIE];
  if (!token) return null;
  const session = sessions.get(token);
  if (!session || session.expires < Date.now()) {
    sessions.delete(token);
    return null;
  }
  const user = loadUsers().find((u) => u.id === session.userId);
  return user || null;
}

function publicUser(user) {
  return {
    id: user.id,
    account: user.account,
    type: user.type,
    name: user.name,
    createdAt: user.createdAt
  };
}

function setSession(res, userId) {
  const token = crypto.randomBytes(24).toString("hex");
  sessions.set(token, { userId, expires: Date.now() + SESSION_TTL });
  res.setHeader("Set-Cookie", `${SESSION_COOKIE}=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800`);
}

function sendJSON(res, status, data) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(data));
}

function accountType(account) {
  if (/^[\w\u4e00-\u9fa5.@-]{3,40}$/.test(account)) return "account";
  return null;
}

async function handleAuth(req, res, pathname) {
  if (pathname === "/api/auth/me" && req.method === "GET") {
    const user = currentUser(req);
    if (!user) return sendJSON(res, 200, { user: null });
    return sendJSON(res, 200, { user: publicUser(user) });
  }

  if (pathname === "/api/auth/register" && req.method === "POST") {
    const body = await readBody(req);
    const account = String(body.account || "").trim();
    const password = String(body.password || "");
    if (!accountType(account)) return sendJSON(res, 400, { error: "请输入 3–40 位账号（字母、数字、下划线或中文）" });
    if (password.length < 6) return sendJSON(res, 400, { error: "密码至少 6 位" });
    const users = loadUsers();
    if (users.some((u) => u.account.toLowerCase() === account.toLowerCase())) {
      return sendJSON(res, 409, { error: "这个账号已经注册过了" });
    }
    const salt = crypto.randomBytes(16).toString("hex");
    const user = {
      id: crypto.randomUUID(),
      account,
      type: accountType(account),
      name: String(body.name || "").trim() || "写作者",
      salt,
      hash: hashPassword(password, salt),
      createdAt: new Date().toISOString()
    };
    users.push(user);
    saveUsers(users);
    setSession(res, user.id);
    return sendJSON(res, 200, { user: publicUser(user) });
  }

  if (pathname === "/api/auth/login" && req.method === "POST") {
    const body = await readBody(req);
    const account = String(body.account || "").trim();
    const password = String(body.password || "");
    const user = loadUsers().find((u) => u.account.toLowerCase() === account.toLowerCase());
    if (!user || hashPassword(password, user.salt) !== user.hash) {
      return sendJSON(res, 401, { error: "账号或密码不对" });
    }
    setSession(res, user.id);
    return sendJSON(res, 200, { user: publicUser(user) });
  }

  if (pathname === "/api/auth/profile" && req.method === "POST") {
    const user = currentUser(req);
    if (!user) return sendJSON(res, 401, { error: "请先登录" });
    const body = await readBody(req);
    const nextName = String(body.name || "").trim();
    if (!nextName) return sendJSON(res, 400, { error: "昵称不能为空" });
    const users = loadUsers();
    const target = users.find((u) => u.id === user.id);
    if (!target) return sendJSON(res, 404, { error: "账号不存在" });
    target.name = nextName;
    saveUsers(users);
    return sendJSON(res, 200, { user: publicUser(target) });
  }

  if (pathname === "/api/auth/account" && req.method === "POST") {
    const user = currentUser(req);
    if (!user) return sendJSON(res, 401, { error: "请先登录" });
    const body = await readBody(req);
    const nextAccount = String(body.account || "").trim();
    const type = accountType(nextAccount);
    if (!type) return sendJSON(res, 400, { error: "请输入 3–40 位账号（字母、数字、下划线或中文）" });
    const users = loadUsers();
    if (users.some((u) => u.id !== user.id && u.account.toLowerCase() === nextAccount.toLowerCase())) {
      return sendJSON(res, 409, { error: "这个账号已经被使用" });
    }
    const target = users.find((u) => u.id === user.id);
    if (!target) return sendJSON(res, 404, { error: "账号不存在" });
    target.account = nextAccount;
    target.type = type;
    saveUsers(users);
    return sendJSON(res, 200, { user: publicUser(target) });
  }

  if (pathname === "/api/auth/password" && req.method === "POST") {
    const user = currentUser(req);
    if (!user) return sendJSON(res, 401, { error: "请先登录" });
    const body = await readBody(req);
    const oldPassword = String(body.oldPassword || "");
    const newPassword = String(body.newPassword || "");
    if (newPassword.length < 6) return sendJSON(res, 400, { error: "新密码至少 6 位" });
    const users = loadUsers();
    const target = users.find((u) => u.id === user.id);
    if (!target || hashPassword(oldPassword, target.salt) !== target.hash) {
      return sendJSON(res, 400, { error: "原密码不对" });
    }
    target.salt = crypto.randomBytes(16).toString("hex");
    target.hash = hashPassword(newPassword, target.salt);
    saveUsers(users);
    return sendJSON(res, 200, { ok: true });
  }

  if (pathname === "/api/auth/logout" && req.method === "POST") {
    const token = parseCookies(req)[SESSION_COOKIE];
    if (token) sessions.delete(token);
    res.setHeader("Set-Cookie", `${SESSION_COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`);
    return sendJSON(res, 200, { ok: true });
  }

  return sendJSON(res, 404, { error: "Not found" });
}

function log(...args) {
  console.log(new Date().toISOString(), ...args);
}

async function callLLM({ system, user, temperature = 0.7, maxTokens = 2000 }) {
  if (!API_KEY) {
    throw new Error("服务端没有配置模型密钥，请设置 DEEPSEEK_API_KEY 后重启。");
  }
  let lastError = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${API_KEY}`
        },
        body: JSON.stringify({
          model: MODEL,
          messages: [
            { role: "system", content: system },
            { role: "user", content: user }
          ],
          temperature,
          max_tokens: maxTokens,
          stream: false
        }),
        signal: AbortSignal.timeout(180000)
      });

      if (!response.ok) {
        const body = await response.text();
        const error = new Error(`模型接口返回 ${response.status}：${body.slice(0, 240)}`);
        error.status = response.status;
        throw error;
      }

      const data = await response.json();
      const content = data && data.choices && data.choices[0] && data.choices[0].message
        ? data.choices[0].message.content
        : "";
      if (!content || !String(content).trim()) throw new Error("模型返回了空内容。");
      return String(content).trim();
    } catch (err) {
      lastError = err;
      if (attempt === 0) await sleep(1200);
    }
  }
  throw lastError;
}

function parseJSON(text) {
  let raw = String(text || "").trim();
  raw = raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  try {
    return JSON.parse(raw);
  } catch (err) {
    const start = raw.indexOf("{");
    const end = raw.lastIndexOf("}");
    if (start >= 0 && end > start) {
      return JSON.parse(raw.slice(start, end + 1));
    }
    throw new Error("模型返回的不是合法 JSON。");
  }
}

function stripLead(text) {
  return String(text || "").replace(/^(先说结论|先给结论|先给判断)[：:，,]\s*/, "").trim();
}

function scrubBanned(text) {
  let out = String(text || "");
  BANNED.forEach((phrase) => {
    if (!phrase) return;
    out = out.split(phrase).join("");
  });
  return out.replace(/[ \t]{2,}/g, " ").replace(/\n{3,}/g, "\n\n").trim();
}

function chineseChars(text) {
  return (String(text || "").match(/[\u4e00-\u9fff]/g) || []).length;
}

function splitParagraphs(text) {
  return scrubBanned(text)
    .replace(/\r/g, "")
    .split(/\n{2,}/)
    .map((p) => stripLead(p.replace(/^#+\s*/, "").replace(/^\*\*|\*\*$/g, "").trim()))
    .filter(Boolean);
}

function clampScore(value, fallback) {
  const num = Number(value);
  return Number.isFinite(num) ? Math.max(0, Math.min(100, Math.round(num))) : fallback;
}

function resolvePersona(body) {
  const raw = body && body.persona;
  if (raw && typeof raw === "object" && String(raw.name || "").trim()) {
    const asList = (v) => Array.isArray(v) ? v.map((x) => String(x).trim()).filter(Boolean).slice(0, 10) : [];
    const style = raw.style || {};
    return {
      id: String(raw.id || (body && body.personaId) || "custom").slice(0, 80),
      name: String(raw.name).trim().slice(0, 30),
      role: String(raw.role || "").trim().slice(0, 80),
      category: String(raw.category || "通用").trim().slice(0, 30),
      tagline: String(raw.tagline || "").trim().slice(0, 120),
      bio: String(raw.bio || "").trim().slice(0, 500),
      L: asList(raw.L).slice(0, 10),
      style: {
        word: asList(style.word),
        sentence: asList(style.sentence),
        discourse: asList(style.discourse)
      },
      anti: asList(raw.anti),
      M: {
        meaning: Math.max(0, Math.min(10, Number(raw.M && raw.M.meaning) || 5)),
        strain: Math.max(0, Math.min(10, Number(raw.M && raw.M.strain) || 5))
      },
      S: Math.max(0, Math.min(10, Number(raw.S) || 5)),
      sample: String(raw.sample || "").trim().slice(0, 800)
    };
  }
  return PERSONAS[body && body.personaId] || PERSONAS.laok;
}

const researchCache = new Map();

function stripHtml(value) {
  return String(value || "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/\s+/g, " ")
    .trim();
}

async function searchSogou(query) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);
  try {
    const url = `https://www.sogou.com/web?query=${encodeURIComponent(query)}`;
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36",
        "Accept-Language": "zh-CN,zh;q=0.9"
      }
    });
    if (!response.ok) return [];
    const html = await response.text();
    const titles = [...html.matchAll(/<h3 class="vr-title">[\s\S]*?<a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a><\/h3>/g)];
    const summaries = [...html.matchAll(/<div class="[^"]*base-ellipsis[^"]*"[^>]*>([\s\S]*?)<\/div>/g)];
    const results = [];
    for (let i = 0; i < Math.min(titles.length, summaries.length); i++) {
      const title = stripHtml(titles[i][2]);
      const snippet = stripHtml(summaries[i][1]);
      if (title && snippet.length >= 20) {
        results.push({ title, snippet, url: titles[i][1] });
      }
      if (results.length >= 6) break;
    }
    return results;
  } catch (err) {
    log("[sogou] failed:", err.message);
    return [];
  } finally {
    clearTimeout(timer);
  }
}

async function searchBing(query) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 9000);
  try {
    const url = `https://cn.bing.com/search?q=${encodeURIComponent(query)}&setlang=zh-Hans`;
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36",
        "Accept-Language": "zh-CN,zh;q=0.9"
      }
    });
    if (!response.ok) return [];
    const html = await response.text();
    const blocks = html.match(/<li class="b_algo"[\s\S]*?<\/li>/g) || [];
    const results = [];
    for (const block of blocks) {
      const h2 = block.match(/<h2[^>]*>([\s\S]*?)<\/h2>/);
      const link = h2 && h2[1].match(/<a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/);
      const p = block.match(/<p[^>]*class="[^"]*b_lineclamp[^"]*"[^>]*>([\s\S]*?)<\/p>/) || block.match(/<p[^>]*>([\s\S]*?)<\/p>/);
      const title = stripHtml(link ? link[2] : (h2 ? h2[1] : ""));
      const snippet = stripHtml(p ? p[1] : "");
      if (title && snippet.length >= 20) results.push({ title, snippet, url: link ? link[1] : "" });
      if (results.length >= 6) break;
    }
    return results;
  } catch (err) {
    log("[bing] failed:", err.message);
    return [];
  } finally {
    clearTimeout(timer);
  }
}

function fallbackQueries(topic) {
  if (/(方言|粤语|陕西话|四川话|上海话)/.test(topic)) {
    return ["各地方言 常用语 例子 嘹咋咧 陕西话 粤语", `${topic} 方言词 具体例子`, "方言 词汇 举例 常用语"];
  }
  if (/(书|阅读|书单|推荐)/.test(topic)) {
    return ["豆瓣 高分 书单 推荐 具体书名", "名人 推荐书单 书名", `${topic} 书单`];
  }
  if (/(电影|剧|片单|综艺)/.test(topic)) {
    return ["豆瓣 高分 片单 具体片名", "经典电影 推荐 片名", `${topic} 片单`];
  }
  return [`${topic} 具体例子 案例 数据 人物`, `${topic} 具体细节`, topic];
}

async function planResearchQueries(topic, product) {
  try {
    const raw = await callLLM({
      system: "你是一位中文资料检索员。只输出严格 JSON，不输出解释。",
      user: `请为下面这个写作主题设计 3 条中文搜索词，目标是找到能直接写进文章的**具体素材**，不是概念解释。

主题：${topic}
核心对象：${product || "未指定"}

要求：
- 如果主题是方言，搜索具体方言词和各地常用语，例如“嘹咋咧”“巴适”“猴赛雷”这种，不要只搜“方言是什么”。
- 如果主题是书/阅读/书单，搜索真实存在的书名和多人推荐的书单，不要只搜“阅读的意义”。
- 如果主题是电影/剧，搜索具体片名和片单。
- 其他主题也优先搜具体人物、地点、作品、数据、案例。
- 输出 3 条，每条不超过 30 字。

JSON：{"queries":["搜索词1","搜索词2","搜索词3"]}`,
      temperature: 0.4,
      maxTokens: 300
    });
    const parsed = parseJSON(raw);
    const queries = Array.isArray(parsed.queries) ? parsed.queries.map(String).filter(Boolean).slice(0, 3) : [];
    return queries.length ? queries : fallbackQueries(topic);
  } catch (err) {
    log("[research queries] fallback:", err.message);
    return fallbackQueries(topic);
  }
}

async function extractResearchFacts(sources, topic) {
  if (!sources.length) return [];
  try {
    const raw = await callLLM({
      system: "你是一位中文资料整理员。只输出严格 JSON，不输出解释。",
      user: `从下面的搜索摘要里提取可以写进文章的具体素材。只提取摘要里真的出现过的内容，不要补造。

主题：${topic}

【摘要】
${sources.map((s, i) => `[${i + 1}] ${s.title}\n${s.snippet}`).join("\n\n")}

【要求】
- 提取 6–10 条；优先方言词、书名、片名、人名、地名、数字、具体事件、原话。
- 每条要包含类型、具体值、简短说明。
- 不要提取“方言很重要”“阅读很有意义”这种概念。
- 如果摘要里没有具体素材，就返回空数组，不要编。

JSON：{"facts":[{"type":"方言词","value":"嘹咋咧","detail":"陕西话，表示好得很、美极了"}]}`,
      temperature: 0.3,
      maxTokens: 700
    });
    const parsed = parseJSON(raw);
    const facts = Array.isArray(parsed.facts) ? parsed.facts : [];
    return facts.map((f) => ({
      type: String(f.type || "素材").trim(),
      value: String(f.value || "").trim(),
      detail: String(f.detail || "").trim()
    })).filter((f) => f.value).slice(0, 10);
  } catch (err) {
    log("[research facts] skipped:", err.message);
    return [];
  }
}

async function researchTopic(topic, product) {
  const key = `${topic || ""}::${product || ""}`;
  if (researchCache.has(key)) return researchCache.get(key);
  const queries = await planResearchQueries(topic, product);
  const all = [];
  for (const q of queries.slice(0, 3)) {
    let results = await searchSogou(q);
    if (!results.length) results = await searchBing(q);
    results.forEach((r) => {
      if (!all.some((x) => x.url === r.url || x.title === r.title)) all.push(r);
    });
    if (all.length >= 8) break;
  }
  const sources = all.slice(0, 8).map((r, i) => ({ ...r, id: i + 1 }));
  const facts = await extractResearchFacts(sources, topic);
  const factText = facts.length
    ? "【具体素材】\n" + facts.map((f) => `- [${f.type}] ${f.value}：${f.detail}`).join("\n")
    : "（没有提取到具体素材，写作时不要编造具体词/书名/人名/数据。）";
  const sourceText = sources.map((r) => `[${r.id}] ${r.title}\n${r.snippet}`).join("\n\n");
  const text = `${factText}\n\n【搜索摘要】\n${sourceText || "（没有检索到资料。）"}`;
  const data = { sources, facts, text };
  researchCache.set(key, data);
  return data;
}

function personaBlock(persona) {
  return [
    `人设：${persona.name}`,
    `分类：${persona.category || "通用"}`,
    `身份：${persona.role}`,
    `一句话：${persona.tagline || ""}`,
    `小传：${persona.bio}`,
    "锚点：",
    ...(persona.L || []).map((x) => `- ${x}`),
    "风格指纹：",
    `- 用词：${(persona.style.word || []).join("；")}`,
    `- 句子：${(persona.style.sentence || []).join("；")}`,
    `- 结构：${(persona.style.discourse || []).join("；")}`,
    `不要写：${(persona.anti || []).join("；")}`,
    `默认状态：M 意义感 ${persona.M.meaning}/10，M 压力 ${persona.M.strain}/10，S 情绪 ${persona.S}/10`
  ].join("\n");
}

function formatGuide(format) {
  const map = {
    深度长文: "先给判断，再分节拆解事实、变量和反例。每一节都要有具体证据或场景，不要写成资料复述。",
    经验分享: "从一个具体经历切入，写踩过的坑、有效的做法、可执行的步骤。允许个人感受，事实要可核实。",
    人物故事: "围绕一个人物写细节、选择、转折和代价。少下结论，让故事自己说话。",
    观点评论: "从现象或新闻切入，拆证据、反方观点和自己的判断。区分事实、推测和观点。",
    问答: "用 5–7 个读者真正会问的问题组织全文。每个回答都要有具体判断，不要泛泛而谈。",
    深度评测: "先给判断，再拆外观与佩戴、硬件、软件生态、真实场景、值不值得买。每一节都要有具体体验或参数，不要写成参数复述。",
    购买指南: "先界定谁适合，再分预算档位、参数怎么看、常见坑、推荐清单。给可执行的判断标准，不替读者做绝对决定。",
    上手体验: "从一个具体使用场景切入，写惊喜、失望、对比和最后建议。允许个人感受，但事实必须可核实。",
    行业观察: "从现象切入，拆产业链、玩家、瓶颈和未来判断。区分事实、推测和观点。",
    清单: "用 N 个理由/坑/建议组织全文，每条一个具体点，避免空泛排比。"
  };
  return map[format] || `按用户自定义的“${format}”组织全文：先明确这篇要解决什么，再分节展开，每节有具体内容。`;
}

function perspectiveFor(persona, body) {
  const category = String(persona.category || "");
  const format = String(body.format || "");
  if (/(新闻|财经|文娱|娱乐|广告)/.test(category)) return "第三人称旁观";
  if (format === "人物故事") return "第三人称旁观";
  if (["经验分享", "上手体验"].includes(format)) return "第一人称，克制";
  if (/(生活|文学|哲学|情感|育儿)/.test(category)) return "第一人称，克制";
  return "第三人称旁观，必要时可引用第一人称";
}

function resolvePerspective(persona, body) {
  const pref = String(body.perspective || "auto");
  if (pref === "first") return "第一人称，克制";
  if (pref === "second") return "第二人称，直接对读者说话但不通篇说教";
  if (pref === "third") return "第三人称旁观";
  if (pref === "objective") return "无人称旁观（纯客观，正文不出现我/我们/你）";
  return perspectiveFor(persona, body);
}

function planPrompt(body, persona, banned = BANNED, research = { text: "" }) {
  const target = Number(body.length) || 3000;
  const count = target >= 4500 ? 7 : target >= 2500 ? 5 : 4;
  const tone = body.tone >= 4 ? "偏感性、具体，有情绪但不煽情" : body.tone <= 2 ? "偏理性、克制，用事实和判断说话" : "平衡，有判断但不极端";
  return `你是一位中文公众号长文策划编辑。请为下面这篇文章设计一个可执行的写作方案。

${personaBlock(persona)}

【领域边界】
只写这个人设和主题所属的领域。若人设与主题不属于科技领域，不要出现硬件、软件、参数、厂商、生态、算账、评测、芯片、传感器等科技词，也不要用科技评测的结构。不要因为默认模板而把文章写成科技产品分析。

【网络资料摘要】
${research.text || "（没有检索到可用资料。不要编造具体例子、数据、人名或出处。）"}

【本次任务】
主题：${body.topic}
核心人物 / 对象：${body.product || "未指定"}
文章形态：${body.format || "深度长文"}
受众：${body.audience || "普通消费者"}
目标篇幅：约 ${target} 字
语气：${tone}
阅读节奏：${body.pace === "slow" ? "慢节奏：段落可以长一些，细节更密，允许停顿和回味" : "快节奏：短段落，句子短，信息密度高，适合快速读完"}
叙事视角：${resolvePerspective(persona, body)}
用户提供的素材（只能把这些当作事实来源，不要自行补充具体参数、价格、销量、日期、引用）：
${body.notes || "（用户未提供额外素材。缺失的信息直接不写，不要写“需要核实 / 官方未公布 / 暂未查到”，也不要用模糊话代替事实。）"}
${Array.isArray(body.attachments) && body.attachments.length ? `用户附了 ${body.attachments.length} 张图片（${body.attachments.join("、")}）。你无法看到图片内容，不要猜测图内文字或细节；需要引用时写“见配图”。` : ""}

【先判断核心对象】
- 先确定这篇文章到底写谁/什么：具体人物、作品、事件、产品，还是一个概念。
- 如果主题指向一个具体人物，但没有给出名字或身份（例如“这个公众人物”“这位明星”“某个人”），不要猜，也不要转而写“名字/称呼”本身。把 needs_clarification 设为 true，clarify_question 写成“请补一下这个人的名字或身份”。
- 如果主题里有人物名，文章必须围绕这个人的经历、作品、选择、争议和影响展开；不要写“名字的意义”“标签的力量”这类元话题，除非用户明确要求语言哲学。
- 如果只有人物名、没有素材，只写你确有把握的公开信息；不确定的不要编。先找这个人身上一个具体的矛盾或选择，再组织全文。
- 中心判断必须是一个可讨论的实质判断，不能是“每个人都不一样”“要做自己”这种正确但空泛的话。

【写作形态要求】
${formatGuide(body.format)}

【公众号写作规范】
- 标题要具体，有判断或利益点；可以用引号框住关键词，但不要标题党。
- 全文必须有开头、中间、结尾。开头第一段可以写场景，但第一段或第二段必须有一句中心句，直接点出全文要说什么；中间自由展开；结尾最后一段必须有一句明确的收束，回应开头。
- 开头直接进入场景、事实或感受，不要题记式引用，不要“随着……”“在当今……”开场。
- 每节有小标题，正文短段落为主，段落长短错落；不要每段一样长。
- 字数由产品界面显示，正文里不要写“全文约多少字”。
- 不要用“第一年 / 第二年 / 第三年”这种逐年流水账组织全文，除非主题本身要求时间线。
- 节奏要统一：快节奏就短段落、短句；慢节奏就允许长段落和停顿，但不要拖沓。
- 结尾给出一个明确判断、感受或画面，可以收束，但不喊口号、不重复全文。
- 结尾最后一段在收束之后，加一句具体的互动问题，邀请读者讲自己的经历或判断；不要写“欢迎留言”“你怎么看”这种通用句。
- 另外给 3–5 个配图搜索词：要具体到场景、物件、人物动作或氛围，方便读者直接搜图；不要写抽象概念。
- 视角要统一：需要旁观的报道用第三人称，不要通篇“我觉得”；个人经验才用第一人称。
- 如果用户选择“无人称纯客观”，正文不要出现“我 / 我们 / 你”，最后一句给评论区的互动问题除外。

【硬性要求】
1. 必须写 ${count} 节，每节标题具体，不要用“第一、第二、最后”这种机械编号。
2. 标题不超过 30 个汉字；导语不超过 80 个汉字。
3. 全文不要出现这些词：${banned.join("、")}；也不要用“先给判断 / 先给结论”作为标题或小标题的开头。以下高频 AI 腔尽量避开：${AI_TEMPLATE_PHRASES.slice(0, 24).join("、")}。
4. 不要用“不要焦虑 / 别焦虑 / 为你好”这类说教句；少用“不是……而是……”的二元骨架；用具体动作和判断代替。
5. 不要空洞排比，不要每段都总结，不要喊口号，不要编造事实。
6. 角度要清楚：这篇文章到底想说什么？中心判断必须能落到具体人物、事件、作品或经历上。
7. 输出严格 JSON，不要 Markdown 代码围栏，不要解释。

JSON 结构：
{
  "title": "文章标题",
  "dek": "导语",
  "subject": "本文写的核心人物/作品/事件/概念",
  "central_question": "这篇文章要回答的一个具体问题",
  "thesis": "一句可讨论的中心判断",
  "claims": ["支撑中心判断的分论点1", "分论点2", "分论点3"],
  "counterpoint": "最有力的反方观点",
  "perspective": "第一人称 / 第三人称旁观 / 无人称旁观",
  "needs_clarification": false,
  "clarify_question": "",
  "images": ["配图搜索词1", "配图搜索词2", "配图搜索词3"],
  "angle": "一句话说明文章角度",
  "reader_takeaway": "读者读完能带走的一个感受或判断",
  "outline": [
    {
      "title": "小节标题",
      "goal": "这一节要解决什么",
      "key_points": ["要点1", "要点2"],
      "evidence_needed": ["需要什么证据 / 素材"],
      "tone": "这一节的语气",
      "target_chars": 500
    }
  ],
  "fact_notes": ["哪些信息需要核实"],
  "risks": ["可能的误判或争议"]
}`;
}

function sectionPrompt({ body, persona, plan, index, total, previous, banned = BANNED, research = { text: "" } }) {
  const section = plan.outline[index];
  const tone = body.tone >= 4 ? "偏感性、具体" : body.tone <= 2 ? "偏理性、克制" : "平衡、有判断";
  return `你正在以「${persona.name}」的身份写一篇公众号长文的第 ${index + 1}/${total} 节。

${personaBlock(persona)}

【领域边界】
只写这个人设和主题所属的领域。若与科技无关，不要出现硬件、软件、参数、厂商、生态、算账、评测等词，也不要用科技评测的结构。

【全文方案】
${JSON.stringify({ title: plan.title, subject: plan.subject, central_question: plan.central_question, thesis: plan.thesis, claims: plan.claims, counterpoint: plan.counterpoint, outline: plan.outline }, null, 2)}

【中心判断】
${plan.thesis || plan.angle || ""}
【要回答的问题】
${plan.central_question || ""}
【分论点】
${(plan.claims || []).map((x) => `- ${x}`).join("\n") || "（按提纲推进）"}

【前文】
${previous || "这是第一节，没有前文。请直接进入内容，不要写“随着……”“在当今……”这类开场。"}

【本节任务】
标题：${section.title}
目标：${section.goal}
要点：${(section.key_points || []).join("；")}
需要留意的证据：${(section.evidence_needed || []).join("；")}
目标字数：约 ${section.target_chars || Math.ceil((Number(body.length) || 3000) / total)} 个汉字
语气：${tone}
叙事视角：${plan.perspective || perspectiveFor(persona, body)}

【用户素材】
${body.notes || "（没有额外素材。缺失的信息直接不写，不要写“需要核实 / 官方未公布 / 暂未查到”。）"}

【网络资料摘要】
${research.text || "（没有检索到可用资料。不要编造具体例子、数据、人名或出处。）"}
只能把资料里的具体例子、数据、人物、作品、方言当作线索；不要整段照抄，不确定的不要写。

【写作要求】
1. 只写这一节的正文，3–6 个自然段，段落之间空一行；不要写小节标题，不要解释你在做什么。
2. 直接进入内容，不要用“首先 / 其次 / 最后”机械串联。
3. 至少有一个具体细节（场景、动作、对话、物件、体验、对比），但只能使用素材里的事实；没有就留白，不要补造。
4. 保持人设语气。中间节不要总结全文，不要重复前文，不要喊口号。
5. 不要出现这些词：${banned.join("、")}；也不要用“先给判断 / 先给结论”开头。以下高频 AI 腔尽量避开：${AI_TEMPLATE_PHRASES.slice(0, 24).join("、")}。
6. 不要用“不要焦虑 / 别焦虑 / 为你好”这类说教句；少用“不是……而是……”的二元骨架。
7. 不要使用“不是……而是……”“不仅……而且……”连续堆叠的对仗句。
8. 不要用“第一年 / 第二年 / 第三年”这种逐年流水账组织这一节。
9. ${index === 0 ? "这是全文开头：第一段可以写场景，但第一段或第二段必须有一句中心句，直接点出全文要说什么，不要绕。" : index === total - 1 ? "这是全文结尾：最后一段必须有一句收束全文、回应开头中心句的话。可以先用画面，再落到一句判断或感受；不能只停在画面上，也不能喊口号。" : "这是中间节：展开一个具体判断或场景，不要抢结尾的收束。"}
10. 本节必须推进中心判断，不能写成与主题无关的元讨论。如果写人物，就写他的经历、作品、选择、争议和影响，不要围绕“名字/称呼/标签”本身做文章。
11. 每一段都要有信息增量：具体人物、事件、作品、场景、对话、数据或判断；不要用空泛形容词和正确废话撑篇幅。
11b. 如果主题是方言、书单、影单，本节必须出现至少 3 个具体方言词、书名或片名，不能只解释概念；用资料里的真实名称，不要编。
12. 视角必须统一。第三人称旁观就写他/她/他们，不要突然写“我觉得”；第一人称就写我，但不要每段都抒情；第二人称用你/你们直接对读者说话，但不要通篇说教。如果视角是“无人称旁观（纯客观）”，正文不要出现“我/我们/你”，最后一句互动问题除外。
13. 节奏：${body.pace === "slow" ? "慢节奏，段落可以长一些，细节更密，允许停顿和回味。" : "快节奏，段落短，句子短，信息密度高，不要拖沓。"}`;
}

function polishPrompt({ article, persona, banned = BANNED }) {
  return `你是「${persona.name}」的编辑。请对下面这篇公众号长文做一次轻润色。

${personaBlock(persona)}

【领域边界】
保持原文所属领域，不要引入硬件、软件、参数、厂商、生态、算账、评测等原文没有的科技词。

【必须保持】
- 所有事实、数字、价格、产品名、观点和段落顺序不变。
- 不新增任何事实，不删除关键信息。
- 不改变人设语气，不把有锋芒的判断磨平。

【只做这些】
- 调整句长节奏，长短句交替。
- 删掉模板化连接词、空泛总结、机械三段式。
- 把“正确的废话”改成具体判断。
- 不要出现这些词：${banned.join("、")}。

【原文】
${JSON.stringify(article, null, 2)}

【输出】
严格 JSON，不要 Markdown 代码围栏：
{"sections":[{"title":"小节标题","paragraphs":["第一段","第二段"]}],"changes":["做了哪些调整"]}`;
}

function reviewPrompt({ article, persona, targetLength, banned = BANNED }) {
  return `你是一位严格的中文长文评审。请按下面四个维度给文章打分（0–100），并找出最多 5 个具体问题。

${personaBlock(persona)}

【文章】
${article.sections.map((s, i) => `【第 ${i + 1} 节 · ${s.title}】\n${s.paragraphs.join("\n\n")}`).join("\n\n")}

【评分口径】
- persona：人设一致性。L 层有没有被违反？语气是否始终像同一个人？
- style：风格相似。词级、句级、篇级特征是否匹配？
- content：内容质量。中心判断是否明确？每一节有没有推进？有没有具体人物、作品、事件、场景或证据？如果通篇在讨论“名字/标签/意义”等元话题，或大量正确废话，content 直接低于 60。方言/书单/影单类文章如果没有具体方言词、书名或片名，也直接低于 60。
- human：人味。越高越像人写，越低越像 AI。看句长节奏、模板化、细节密度、结构是否过整。
- 目标篇幅约 ${targetLength} 字；如果实际字数明显不足，要在 content 或 issues 里指出。

【问题要求】
1. 最多 5 个，按严重程度排序；没有就返回空数组，不要凑数。
2. quote 必须逐字出现在文章里，不能改写、不能省略。
3. 如果人设或主题不属于科技领域，却出现硬件、软件、参数、厂商、生态、算账、评测等词，要标成“人设漂移”或“AI 腔”。
   如果全文用“第一年 / 第二年 / 第三年”逐年流水账组织，标成“结构”。
   如果开头没有中心句，或最后一段没有收束、只停在画面上，也要标成“结构”。
   如果最后没有一句具体的评论区互动问题，或者只写“欢迎留言/你怎么看”，标成“结构”。
   如果旁观的报道/人物稿通篇是“我觉得/我感到”，或第一人称文章突然切到第三人称，标成“人设漂移”。
   如果用户选择了“无人称纯客观”，正文出现“我/我们/你”（最后一句互动问题除外），标成“人设漂移”。
   如果用户选择了“第二人称”，正文几乎没有“你/你们”，或通篇变成说教，标成“人设漂移”或“说教腔”。
4. type 用：人设漂移 / AI 腔 / 事实口径 / 结构 / 节奏 / 标题 / 说教腔 / 内容空泛。
   尤其注意：说教腔包括“不要焦虑”“为你好”“你要相信”等句式；AI 腔包括“综上所述”“值得注意的是”“不是……而是……”等模板。
5. 文章不能出现这些全局禁用词：${banned.join("、")}；出现就标成 AI 腔或说教腔。
6. 如果文章没有中心判断，或每一节只是换说法重复，标成“内容空泛”，severity 至少 medium。
7. severity 用：high / medium / low。
8. fix 用：rewrite（需要改这一段） / fact（需要人工核实） / manual（其他）。
9. impact 用对象，例如 {"persona":6,"style":2}，数值 2–10。
10. 事实问题优先标 high；没有来源的数字、价格、销量、日期，不要放过。
11. 另外选出 3–5 句全文最核心、最值得读者记住的句子，放在 highlights 里；必须逐字来自原文，每句不超过 80 字。

【输出】
严格 JSON，不要 Markdown 代码围栏：
{
  "scores": {"persona": 0, "style": 0, "content": 0, "human": 0},
  "summary": "一句话总评",
  "highlights": ["原文中的核心句"],
  "issues": [
    {
      "type": "人设漂移",
      "severity": "high",
      "section": 3,
      "quote": "原文原句",
      "evidence": "为什么是问题",
      "suggestion": "怎么改",
      "route": "重写第 3 节",
      "fix": "rewrite",
      "impact": {"persona": 6, "style": 2}
    }
  ]
}`;
}

function normalizePlan(raw, body) {
  const plan = raw && typeof raw === "object" ? raw : {};
  const target = Number(body.length) || 3000;
  const count = target >= 4500 ? 7 : target >= 2500 ? 5 : 4;
  const outline = Array.isArray(plan.outline) ? plan.outline.filter((x) => x && x.title).slice(0, count) : [];
  while (outline.length < count) {
    outline.push({
      title: outline.length === 0 ? "先把问题说清楚" : `再拆一层：第 ${outline.length + 1} 个判断`,
      goal: "补充一个具体判断",
      key_points: [],
      evidence_needed: [],
      tone: "平衡",
      target_chars: Math.ceil(target / count)
    });
  }
  const topic = String(body.topic || "这篇文章").trim();
  const thesis = String(plan.thesis || plan.angle || plan.reader_takeaway || `围绕${topic}给出一个具体判断`).trim();
  return {
    title: stripLead(String(plan.title || topic)).slice(0, 40),
    dek: String(plan.dek || "").slice(0, 120),
    subject: String(plan.subject || body.product || topic).slice(0, 100),
    central_question: String(plan.central_question || `这篇文章要回答：${topic}到底意味着什么？`).slice(0, 160),
    thesis: thesis.slice(0, 240),
    claims: Array.isArray(plan.claims)
      ? plan.claims.map((x) => String(x).trim()).filter(Boolean).slice(0, 6)
      : outline.map((s) => String(s.goal || s.title || "").trim()).filter(Boolean).slice(0, 6),
    counterpoint: String(plan.counterpoint || "").slice(0, 200),
    perspective: String(plan.perspective || "").trim(),
    needs_clarification: !!plan.needs_clarification,
    clarify_question: String(plan.clarify_question || "主题里像是具体人物，但没有给出名字或身份。请在“核心人物 / 对象”里补上名字，再生成。").slice(0, 200),
    angle: String(plan.angle || thesis).slice(0, 180),
    reader_takeaway: String(plan.reader_takeaway || ""),
    images: Array.isArray(plan.images)
      ? plan.images.map((x) => String(x).trim()).filter(Boolean).slice(0, 5)
      : [topic, ...outline.slice(0, 3).map((s) => String(s.title || ""))].filter(Boolean).slice(0, 4),
    outline: outline.map((s) => Object.assign({}, s, { title: stripLead(String(s.title)) })),
    fact_notes: Array.isArray(plan.fact_notes) ? plan.fact_notes : [],
    risks: Array.isArray(plan.risks) ? plan.risks : []
  };
}

function assignImpact(type) {
  const map = {
    人设漂移: { persona: 6, style: 2 },
    "AI 腔": { human: 8, style: 2 },
    事实口径: { content: 5 },
    结构: { content: 4 },
    节奏: { style: 5 },
    标题: { style: 3 },
    说教腔: { style: 5, human: 4 },
    内容空泛: { content: 8 }
  };
  return map[type] || { content: 3 };
}

function normalizeReview(raw, article, targetLength) {
  const review = raw && typeof raw === "object" ? raw : {};
  const scores = review.scores || {};
  const normalized = {
    scores: {
      persona: clampScore(scores.persona, 84),
      style: clampScore(scores.style, 80),
      content: clampScore(scores.content, 82),
      human: clampScore(scores.human, 78)
    },
    summary: String(review.summary || "完成自检。"),
    highlights: [],
    issues: []
  };

  const fullText = article.sections.map((s) => s.paragraphs.join("\n")).join("\n");
  const compact = fullText.replace(/\s+/g, "");
  if (Array.isArray(review.highlights)) {
    normalized.highlights = review.highlights
      .map((x) => String(x).trim())
      .filter((x) => x && fullText.includes(x))
      .slice(0, 5);
  }
  const issues = Array.isArray(review.issues) ? review.issues : [];

  issues.slice(0, 5).forEach((rawIssue) => {
    if (!rawIssue || !rawIssue.quote) return;
    const quote = String(rawIssue.quote).trim();
    const quoteOk = fullText.includes(quote) || compact.includes(quote.replace(/\s+/g, ""));
    if (!quoteOk) return;
    const type = ["人设漂移", "AI 腔", "事实口径", "结构", "节奏", "标题", "说教腔", "内容空泛"].includes(rawIssue.type)
      ? rawIssue.type
      : "结构";
    const severity = ["high", "medium", "low"].includes(rawIssue.severity) ? rawIssue.severity : "medium";
    let section = Number(rawIssue.section);
    if (!Number.isInteger(section) || section < 1 || section > article.sections.length) {
      const idx = article.sections.findIndex((s) => s.paragraphs.some((p) => p.includes(quote.slice(0, 12))));
      section = idx >= 0 ? idx + 1 : 1;
    }
    const fix = ["rewrite", "fact", "manual"].includes(rawIssue.fix)
      ? rawIssue.fix
      : type === "事实口径" ? "fact" : "rewrite";
    const impact = {};
    const rawImpact = rawIssue.impact && typeof rawIssue.impact === "object"
      ? rawIssue.impact
      : assignImpact(type);
    Object.entries(rawImpact).forEach(([key, value]) => {
      const num = Number(value);
      if (Number.isFinite(num)) impact[key] = num;
    });
    if (!Object.keys(impact).length) Object.assign(impact, assignImpact(type));
    normalized.issues.push({
      id: "r" + (normalized.issues.length + 1),
      type,
      severity,
      section,
      quote,
      evidence: String(rawIssue.evidence || "与全文的语气或事实口径不一致。"),
      suggestion: String(rawIssue.suggestion || "按人设和上下文重写这一段。"),
      route: String(rawIssue.route || (fix === "fact" ? "人工核实" : `重写第 ${section} 节`)),
      fix,
      impact
    });
  });

  const totalChars = chineseChars(fullText);
  if (totalChars < targetLength * 0.65) {
    normalized.issues.unshift({
      id: "len",
      type: "结构",
      severity: "medium",
      section: 1,
      quote: article.sections[0].paragraphs[0].slice(0, 40),
      evidence: `当前约 ${totalChars} 字，目标约 ${targetLength} 字，篇幅明显不足。`,
      suggestion: "补一个具体场景、对比或拆解，让每一节都有信息增量。",
      route: "重写第 1 节",
      fix: "rewrite",
      impact: { content: 5 }
    });
    normalized.summary += ` 当前篇幅约 ${totalChars} 字，低于目标。`;
  }

  return normalized;
}

function hasReaderInteraction(article) {
  const paragraphs = article.sections[article.sections.length - 1]?.paragraphs || [];
  const last = paragraphs[paragraphs.length - 1] || "";
  return /[？?]/.test(last) && /(你|评论区|留言|说说|会怎么|有没有|哪一|愿意)/.test(last);
}

async function ensureReaderInteraction(article, persona, body, banned) {
  if (hasReaderInteraction(article)) return;
  const last = article.sections[article.sections.length - 1];
  if (!last) return;
  try {
    const question = await callLLM({
      system: "你是一位中文编辑。只输出一句给读者的互动问题，不要解释，不要新事实。",
      user: `请为下面这篇文章的结尾写一句具体的评论区互动问题。

${personaBlock(persona)}

【文章标题】
${article.title}

【结尾】
${last.paragraphs.join("\n")}

【要求】
- 只写一句问题，不超过 45 字。
- 承接文章内容，问一个具体的选择、经历或判断。
- 不要“欢迎留言”“你怎么看”“说说你的看法”这种模板句。
- 不要出现“需要核实 / 官方未公布 / 暂未查到”。
- 不要出现这些词：${banned.join("、")}。
- 只输出问题本身。`,
      temperature: 0.7,
      maxTokens: 120
    });
    const q = scrubBanned(String(question || "").trim());
    if (q && /[？?]/.test(q)) {
      last.paragraphs.push(q);
      return;
    }
  } catch (err) {
    log("[interaction] skipped:", err.message);
  }
  const fallback = `如果是你，面对${body.topic || "这件事"}，会怎么选？`;
  last.paragraphs.push(scrubBanned(fallback));
}

function makeArticle(plan, sectionTexts) {
  return {
    title: stripLead(scrubBanned(plan.title)),
    dek: scrubBanned(plan.dek),
    sections: plan.outline.map((section, index) => ({
      id: "s" + (index + 1),
      title: stripLead(scrubBanned(section.title)),
      paragraphs: sectionTexts[index]
    }))
  };
}

function sendSSE(res, event, data) {
  if (res.writableEnded || res.destroyed) return;
  res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
}

function titlesPrompt(body, persona, research) {
  return `你是一位中文公众号选题编辑。请围绕下面的主题，给出 5 个不同方向的标题。

${personaBlock(persona)}

主题：${body.topic}
核心人物 / 对象：${body.product || "未指定"}
文章形态：${body.format || "深度长文"}
受众：${body.audience || "普通读者"}
节奏：${body.pace === "slow" ? "慢节奏" : "快节奏"}
叙事人称：${resolvePerspective(persona, body)}

【网络资料摘要】
${research.text || "（没有检索到可用资料。不要编造具体例子、数据、人名或出处。）"}

【要求】
- 5 个标题方向要不同：人物切口、观点判断、经验方法、现象/数据、故事/场景，尽量覆盖不同写作形式。
- 至少 3 个标题要带一个具体专名/方言词/书名/人名/地点，不能只写抽象概念。
- 每个标题都要具体，能看出文章写什么；不要标题党，不要空泛。
- 可以使用资料里的具体例子，但不要整句照抄。
- 不要出现“需要核实 / 官方未公布 / 暂未查到”。
- 每个标题附一个 angle，说明这篇从哪个角度写；再附 type，例如“人物 / 观点 / 方法 / 现象 / 故事”。

【输出】
严格 JSON，不要 Markdown 代码围栏：
{"titles":[{"title":"标题1","angle":"角度1","type":"人物"},{"title":"标题2","angle":"角度2","type":"观点"},{"title":"标题3","angle":"角度3","type":"方法"},{"title":"标题4","angle":"角度4","type":"现象"},{"title":"标题5","angle":"角度5","type":"故事"}]}`;
}

function outlinesPrompt(body, persona, research, selectedTitle) {
  return `你是一位中文公众号策划编辑。标题已经确定，请给出 3 种不同结构的大纲。

${personaBlock(persona)}

标题：${selectedTitle}
主题：${body.topic}
核心人物 / 对象：${body.product || "未指定"}
文章形态：${body.format || "深度长文"}
受众：${body.audience || "普通读者"}
节奏：${body.pace === "slow" ? "慢节奏" : "快节奏"}
叙事人称：${resolvePerspective(persona, body)}

【网络资料摘要】
${research.text || "（没有检索到可用资料。不要编造具体例子、数据、人名或出处。）"}

【要求】
- 3 种大纲必须结构不同：例如“人物故事型 / 观点论证型 / 经验方法型”，不能只是换小标题。
- 每份大纲至少使用 3 个具体素材：方言词、书名、片名、人名、地名、数字、具体事件或原话；写进对应小节的 key_points，不能只写概念。
- 每个大纲必须有开头、中间、结尾；第一节 part 写“开头”，最后一节 part 写“结尾”，中间写“中间”。
- 每个大纲要有：thesis（中心判断）、central_question（要回答的问题）、sections（4–6 节）。
- 每节写清 title、goal、key_points（2–4 条），以及这一节大概写什么。
- 尽量把资料里的具体例子、人物、方言、数据、作品写进对应小节；不要空谈概念。
- 如果主题是方言、书单、影单，必须出现具体的方言词、书名或片名；没有具体素材就不要写这个方向。
- 资料只能当线索；不确定的具体信息不要写，绝对不要写“需要核实 / 官方未公布 / 暂未查到”。

【输出】
严格 JSON，不要 Markdown 代码围栏：
{"outlines":[{"title":"${selectedTitle}","thesis":"中心判断","central_question":"要回答的问题","sections":[{"part":"开头","title":"小节标题","goal":"这一节要解决什么","key_points":["具体内容1","具体内容2"]}]}]}`;
}

function normalizeTitles(raw) {
  const list = raw && Array.isArray(raw.titles) ? raw.titles : [];
  const titles = list
    .map((t) => ({ title: String(t.title || "").trim(), angle: String(t.angle || "").trim(), type: String(t.type || "").trim() }))
    .filter((t) => t.title)
    .slice(0, 5);
  while (titles.length < 5) titles.push({ title: "", angle: "", type: "" });
  return titles;
}

function normalizeOutlines(raw) {
  const list = raw && Array.isArray(raw.outlines) ? raw.outlines : [];
  return list.slice(0, 3).map((o) => {
    const sections = (Array.isArray(o.sections) ? o.sections : []).slice(0, 6).map((sec, i, arr) => ({
      part: String(sec.part || (i === 0 ? "开头" : i === arr.length - 1 ? "结尾" : "中间")),
      title: String(sec.title || "").trim(),
      goal: String(sec.goal || "").trim(),
      key_points: Array.isArray(sec.key_points) ? sec.key_points.map(String).filter(Boolean).slice(0, 5) : []
    })).filter((sec) => sec.title);
    return {
      title: String(o.title || "").trim(),
      thesis: String(o.thesis || "").trim(),
      central_question: String(o.central_question || "").trim(),
      sections
    };
  }).filter((o) => o.sections.length >= 2);
}

async function handleTitles(req, res, body) {
  try {
    const persona = resolvePersona(body);
    const research = await researchTopic(body.topic, body.product);
    const raw = await callLLM({
      system: "你是一位中文公众号选题编辑。只输出严格 JSON，不输出解释。不要编造事实。",
      user: titlesPrompt(body, persona, research),
      temperature: 0.9,
      maxTokens: 1400
    });
    sendJSON(res, 200, { titles: normalizeTitles(parseJSON(raw)), sources: research.sources });
  } catch (err) {
    sendJSON(res, 500, { error: err.message || "标题生成失败" });
  }
}

async function handleOutlines(req, res, body) {
  try {
    const persona = resolvePersona(body);
    const research = await researchTopic(body.topic, body.product);
    const selectedTitle = String(body.selectedTitle || body.topic || "").trim();
    const raw = await callLLM({
      system: "你是一位中文公众号策划编辑。只输出严格 JSON，不输出解释。不要编造事实。",
      user: outlinesPrompt(body, persona, research, selectedTitle),
      temperature: 0.8,
      maxTokens: 2600
    });
    sendJSON(res, 200, { outlines: normalizeOutlines(parseJSON(raw)), sources: research.sources });
  } catch (err) {
    sendJSON(res, 500, { error: err.message || "大纲生成失败" });
  }
}

function normalizeProvidedPlan(outline, body, persona, research) {
  const target = Number(body.length) || 3000;
  const sections = (outline.sections || []).slice(0, 6).map((sec, i, arr) => ({
    title: String(sec.title || "").trim(),
    goal: String(sec.goal || "").trim(),
    key_points: Array.isArray(sec.key_points) ? sec.key_points.map(String).filter(Boolean).slice(0, 5) : [],
    evidence_needed: [],
    tone: "",
    part: String(sec.part || (i === 0 ? "开头" : i === arr.length - 1 ? "结尾" : "中间")),
    target_chars: Math.ceil(target / Math.max(1, (outline.sections || []).length))
  })).filter((sec) => sec.title);
  return {
    title: String(body.selectedTitle || outline.title || body.topic || "").trim(),
    dek: "",
    subject: String(body.product || body.topic || "").trim(),
    central_question: String(outline.central_question || "").trim(),
    thesis: String(outline.thesis || "").trim(),
    claims: sections.map((s) => s.goal).filter(Boolean),
    counterpoint: "",
    perspective: resolvePerspective(persona, body),
    needs_clarification: false,
    clarify_question: "",
    images: [body.topic, ...sections.map((s) => s.title)].filter(Boolean).slice(0, 5),
    outline: sections,
    fact_notes: [],
    risks: []
  };
}

async function handleGenerate(req, res, body) {
  res.writeHead(200, {
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-cache, no-transform",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no"
  });
  if (typeof res.flushHeaders === "function") res.flushHeaders();

  let closed = false;
  res.on("close", () => { closed = true; });
  const heartbeat = setInterval(() => {
    if (!closed && !res.writableEnded) res.write(": ping\n\n");
  }, 15000);

  const persona = resolvePersona(body);
  const targetLength = Number(body.length) || 3000;
  const research = await researchTopic(body.topic, body.product);
  const banned = Array.isArray(body.banned) && body.banned.length
    ? body.banned.map((x) => String(x).trim()).filter(Boolean).slice(0, 40)
    : BANNED;

  try {
    sendSSE(res, "stage", {
      step: 1,
      title: "正在读人设",
      sub: "把锚点、风格和受众放进上下文",
      live: "读取锚点、风格和受众…",
      percent: 6
    });

    let plan;
    if (body.selectedOutline && Array.isArray(body.selectedOutline.sections) && body.selectedOutline.sections.length) {
      plan = normalizeProvidedPlan(body.selectedOutline, body, persona, research);
    } else {
      const planRaw = await callLLM({
        system: "你是一位严谨的中文公众号策划编辑。你只输出严格 JSON，不输出解释。不要编造事实。",
        user: planPrompt(body, persona, banned, research),
        temperature: 0.7,
        maxTokens: 2200
      });
      plan = normalizePlan(parseJSON(planRaw), body);
      plan.perspective = resolvePerspective(persona, body);
    }
    if (closed) return;
    if (plan.needs_clarification) {
      sendSSE(res, "clarify", { message: plan.clarify_question });
      res.end();
      return;
    }
    sendSSE(res, "plan", {
      title: plan.title,
      dek: plan.dek,
      angle: plan.angle,
      outline: plan.outline.map((s) => s.title),
      factNotes: plan.fact_notes
    });

    sendSSE(res, "stage", {
      step: 2,
      title: "正在搭骨架，再写正文",
      sub: `已定 ${plan.outline.length} 节，开始逐节写`,
      live: "提纲已生成，开始逐节写正文…",
      percent: 18
    });

    const sectionTexts = [];
    for (let i = 0; i < plan.outline.length; i++) {
      if (closed) return;
      const section = plan.outline[i];
      const percent = 20 + Math.round(((i + 0.5) / plan.outline.length) * 54);
      sendSSE(res, "stage", {
        step: 2,
        title: `正在写第 ${i + 1} 节`,
        sub: `第 ${i + 1}/${plan.outline.length} 节 · ${section.title}`,
        live: `正在写第 ${i + 1}/${plan.outline.length} 节：${section.title}`,
        percent
      });

      const previous = i === 0
        ? ""
        : `已完成的小节：${plan.outline.slice(0, i).map((s) => s.title).join("；")}\n上一节结尾：${sectionTexts[i - 1].join("").slice(-180)}`;

      const raw = await callLLM({
        system: "你是一位中文公众号作者。你只写正文，不解释，不编造事实。",
        user: sectionPrompt({
          body,
          persona,
          plan,
          index: i,
          total: plan.outline.length,
          previous,
          banned,
          research
        }),
        temperature: 0.8,
        maxTokens: 1600
      });
      if (closed) return;

      let paragraphs = splitParagraphs(raw);
      if (!paragraphs.length) throw new Error(`第 ${i + 1} 节没有生成有效正文。`);
      const minChars = Math.max(180, Math.floor((Number(section.target_chars) || targetLength / plan.outline.length) * 0.55));
      if (paragraphs.join("").length < minChars) {
        sendSSE(res, "warning", { message: `第 ${i + 1} 节内容偏少，补写一次。` });
        try {
          const retryRaw = await callLLM({
            system: "你是一位中文公众号作者。你只写正文，不解释，不编造事实。",
            user: sectionPrompt({
              body, persona, plan, index: i, total: plan.outline.length, previous, banned, research
            }) + `\n\n【上一版的问题】\n上一版只有 ${paragraphs.join("").length} 字，内容太空。请补足具体人物、事件、作品、场景、对话或判断，写到约 ${section.target_chars || Math.ceil(targetLength / plan.outline.length)} 字。不要重复上一版，不要写空话。`,
            temperature: 0.7,
            maxTokens: 1800
          });
          if (closed) return;
          const retryParagraphs = splitParagraphs(retryRaw);
          if (retryParagraphs.join("").length > paragraphs.join("").length) paragraphs = retryParagraphs;
        } catch (err) {
          log(`[section ${i + 1}] retry skipped:`, err.message);
        }
      }
      sectionTexts.push(paragraphs);
      sendSSE(res, "section", {
        index: i + 1,
        total: plan.outline.length,
        title: section.title,
        paragraphs,
        percent: 20 + Math.round(((i + 1) / plan.outline.length) * 54)
      });
    }

    let article = makeArticle(plan, sectionTexts);

    sendSSE(res, "stage", {
      step: 3,
      title: "正在润色去 AI 化",
      sub: "调节奏、删模板句，保留事实和观点",
      live: "删除模板句、调整句长，保留事实…",
      percent: 82
    });

    try {
      const polishedRaw = await callLLM({
        system: "你是一位中文长文编辑。你只输出严格 JSON，不输出解释。不要新增事实。",
        user: polishPrompt({ article, persona, banned }),
        temperature: 0.5,
        maxTokens: 6000
      });
      const polished = parseJSON(polishedRaw);
      if (polished && Array.isArray(polished.sections) && polished.sections.length === article.sections.length) {
        const nextSections = polished.sections.map((s, i) => ({
          id: article.sections[i].id,
          title: scrubBanned(s.title || article.sections[i].title),
          paragraphs: Array.isArray(s.paragraphs)
            ? s.paragraphs.map((p) => scrubBanned(p)).filter(Boolean)
            : article.sections[i].paragraphs
        }));
        if (nextSections.every((s) => s.paragraphs.length > 0)) {
          article = { title: article.title, dek: article.dek, sections: nextSections };
          sendSSE(res, "polish", { changes: polished.changes || [] });
        }
      }
    } catch (err) {
      log("[polish] skipped:", err.message);
      sendSSE(res, "warning", { message: "润色步骤跳过了，正文仍可用。" });
    }

    await ensureReaderInteraction(article, persona, body, banned);
    if (closed) return;

    sendSSE(res, "stage", {
      step: 4,
      title: "正在自检",
      sub: "人设、风格、AI 痕迹、事实四项打分",
      live: "按人设、风格、事实逐项检查…",
      percent: 92
    });

    let review;
    try {
      const reviewRaw = await callLLM({
        system: "你是一位严格的中文长文评审。你只输出严格 JSON，不输出解释。",
        user: reviewPrompt({ article, persona, targetLength, banned }),
        temperature: 0.2,
        maxTokens: 2800
      });
      review = normalizeReview(parseJSON(reviewRaw), article, targetLength);
    } catch (err) {
      log("[review] fallback:", err.message);
      review = normalizeReview({}, article, targetLength);
      sendSSE(res, "warning", { message: "自检评分未完成，使用了保守分数。" });
    }

    sendSSE(res, "review", {
      scores: review.scores,
      summary: review.summary,
      issueCount: review.issues.length
    });

    const now = new Date().toISOString();
    const project = {
      id: "p-" + Date.now(),
      personaId: persona.id || body.personaId || "custom",
      title: article.title,
      dek: article.dek,
      status: "review",
      version: 1,
      updatedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      sections: article.sections,
      thesis: plan.thesis || "",
      centralQuestion: plan.central_question || "",
      perspective: plan.perspective || "",
      imageSuggestions: plan.images || [],
      sources: research.sources || [],
      review,
      meta: {
        format: body.format,
        audience: body.audience,
        length: targetLength,
        tone: body.tone,
        pace: body.pace || "fast",
        perspective: plan.perspective || "",
        product: body.product || "",
        includeAdvice: !!body.includeAdvice,
        generated: true,
        generatedAt: now
      }
    };

    sendSSE(res, "done", { project });
    res.end();
  } catch (err) {
    log("[generate] error:", err.message);
    sendSSE(res, "error", { message: err.message || "生成失败，请重试。" });
    res.end();
  } finally {
    clearInterval(heartbeat);
  }
}

async function handleFix(req, res, body) {
  try {
    const persona = resolvePersona(body);
    const banned = Array.isArray(body.banned) && body.banned.length
      ? body.banned.map((x) => String(x).trim()).filter(Boolean).slice(0, 40)
      : BANNED;
    const original = String(body.paragraph || "");
    if (!original) throw new Error("缺少需要重写的段落。");

    const system = "你是一位中文长文编辑。只输出重写后的正文，不要标题、不要解释、不要编造事实。";
    const user = `请以「${persona.name}」的身份重写下面这一段，解决指定问题。

${personaBlock(persona)}

【文章标题】
${body.title || ""}

【所在小节】
${body.sectionTitle || ""}

【要重写的段落】
${original}

【问题】
类型：${body.issue && body.issue.type ? body.issue.type : "AI 腔"}
判断：${body.issue && body.issue.evidence ? body.issue.evidence : "读起来不像这个人写的。"}
建议：${body.issue && body.issue.suggestion ? body.issue.suggestion : "按人设和上下文重写。"}

【要求】
- 只重写这一段，保持事实、观点和前后文衔接。
- 不新增具体参数、价格、销量、日期、引用；没有就不写，不要写“需要核实 / 官方未公布 / 暂未查到”。
- 不要出现这些词：${banned.join("、")}。
- 只输出正文段落，不要“这里是重写”的解释。`;

    const text = await callLLM({ system, user, temperature: 0.6, maxTokens: 900 });
    res.writeHead(200, { "Content-Type": "application/json; charset=utf-8" });
    res.end(JSON.stringify({ paragraph: scrubBanned(text) }));
  } catch (err) {
    res.writeHead(500, { "Content-Type": "application/json; charset=utf-8" });
    res.end(JSON.stringify({ error: err.message || "重写失败" }));
  }
}

async function handlePersonaAnalyze(req, res, body) {
  try {
    const text = String(body.text || "").trim();
    if (text.length < 80) throw new Error("样稿太短，至少贴 80 字。");
    if (text.length > 16000) throw new Error("样稿太长，一次最多 16000 字。");
    const system = "你是一位人设编辑。你只输出严格 JSON，不输出解释。";
    const user = `读下面的公众号样稿，提炼作者的人设与写作风格，供平台建人设卡。

【样稿】
${text}

【要求】
- 只提炼可复用的特征，不要抄原文句子。
- 锚点写作者相信什么、怎么写、绝不写什么；每条一句，5–7 条。
- 风格分三层：词级（用词习惯）、句级（句子节奏）、篇级（结构习惯），每层 3–5 条，具体可执行。
- 分类从这些里选一个最接近的：财经、新闻、科技、育儿、生活 / 文学、情感、文娱；实在不属于就写“通用”。
- 身份写成“领域 · 身份”，例如“财经观察 · 前投行分析师”。
- 小传 60–100 字，写经历、在意什么、为什么写。
- M 意义感、M 压力、S 情绪默认值 0–10。

【输出】
严格 JSON，不要 Markdown 代码围栏：
{"category":"","role":"","bio":"","anchors":[""],"style":{"word":[""],"sentence":[""],"discourse":[""]},"M":{"meaning":5,"strain":5},"S":5}`;
    const raw = await callLLM({ system, user, temperature: 0.35, maxTokens: 1800 });
    const parsed = parseJSON(raw);
    const anchors = Array.isArray(parsed.anchors) ? parsed.anchors.map(String).filter(Boolean).slice(0, 8) : [];
    const style = parsed.style || {};
    const result = {
      category: String(parsed.category || "").trim(),
      role: String(parsed.role || "").trim(),
      bio: String(parsed.bio || "").trim(),
      anchors,
      style: {
        word: Array.isArray(style.word) ? style.word.map(String).filter(Boolean).slice(0, 6) : [],
        sentence: Array.isArray(style.sentence) ? style.sentence.map(String).filter(Boolean).slice(0, 6) : [],
        discourse: Array.isArray(style.discourse) ? style.discourse.map(String).filter(Boolean).slice(0, 6) : []
      },
      M: {
        meaning: Math.max(0, Math.min(10, Number(parsed.M && parsed.M.meaning) || 5)),
        strain: Math.max(0, Math.min(10, Number(parsed.M && parsed.M.strain) || 5))
      },
      S: Math.max(0, Math.min(10, Number(parsed.S) || 5))
    };
    sendJSON(res, 200, result);
  } catch (err) {
    sendJSON(res, 500, { error: err.message || "分析失败" });
  }
}

async function handlePolish(req, res, body) {
  try {
    const persona = resolvePersona(body);
    const text = String(body.text || "").trim();
    const banned = Array.isArray(body.banned) && body.banned.length
      ? body.banned.map((x) => String(x).trim()).filter(Boolean).slice(0, 40)
      : BANNED;
    if (!text) throw new Error("没有可润色的文字。");
    if (text.length > 8000) throw new Error("一次最多润色 8000 字。");
    const system = "你是一位中文长文编辑。你只输出严格 JSON，不输出解释。不要新增事实。";
    const user = `请以「${persona.name}」的身份润色下面这段文字。

${personaBlock(persona)}

【所在位置】
${body.context || "公众号长文"}

【用户特别圈出的部分】
${body.highlight || "（没有特别圈出，整段处理）"}

【原文】
${text}

【要求】
- 保留所有事实、数字、价格、观点、人称和段落顺序。
- 删掉模板化连接词、三段式排比、空泛总结、对称句、推销式助手腔。
- 句长要错落：允许 4–8 字的短句，不要每句一样长。
- 不要出现这些词：${banned.join("、")}。
- 不要新增任何具体参数、价格、销量、日期、引用；没有就保留原文的说法。
- 如果原文已经很自然，可以只做很小的调整。

【输出】
严格 JSON，不要 Markdown 代码围栏：
{"text":"润色后的文字，段落之间用两个换行","changes":["改了什么"]}`;
    const raw = await callLLM({ system, user, temperature: 0.55, maxTokens: 2600 });
    const parsed = parseJSON(raw);
    const out = stripLead(scrubBanned(parsed.text || ""));
    if (!out) throw new Error("模型没有返回有效文字。");
    sendJSON(res, 200, { text: out, changes: Array.isArray(parsed.changes) ? parsed.changes : [] });
  } catch (err) {
    sendJSON(res, 500, { error: err.message || "润色失败" });
  }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", (chunk) => {
      raw += chunk;
      if (raw.length > 2 * 1024 * 1024) {
        reject(new Error("请求体过大。"));
        req.destroy();
      }
    });
    req.on("end", () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch (err) {
        reject(new Error("请求体不是合法 JSON。"));
      }
    });
    req.on("error", reject);
  });
}

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
  ".md": "text/markdown; charset=utf-8"
};

function serveStatic(req, res, pathname) {
  const clean = decodeURIComponent(pathname.split("?")[0]);
  const target = clean === "/" ? path.join(WEB, "index.html") : path.join(WEB, clean);
  const resolved = path.resolve(target);
  if (!resolved.startsWith(WEB + path.sep) && resolved !== path.join(WEB, "index.html")) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }
  fs.readFile(resolved, (err, data) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      res.end("Not found");
      return;
    }
    const ext = path.extname(resolved).toLowerCase();
    res.writeHead(200, {
      "Content-Type": MIME[ext] || "application/octet-stream",
      "Cache-Control": "no-store"
    });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "127.0.0.1"}`);
  const pathname = url.pathname;

  if (pathname.startsWith("/api/auth/")) {
    try {
      await handleAuth(req, res, pathname);
    } catch (err) {
      if (!res.headersSent) sendJSON(res, 500, { error: err.message || "账号服务异常" });
    }
    return;
  }

  if (req.method === "GET" && pathname === "/api/health") {
    res.writeHead(200, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
    res.end(JSON.stringify({ ok: true, configured: !!API_KEY, model: MODEL }));
    return;
  }

  if (req.method === "POST" && pathname === "/api/titles") {
    if (!currentUser(req)) return sendJSON(res, 401, { error: "请先登录" });
    try {
      await handleTitles(req, res, await readBody(req));
    } catch (err) {
      if (!res.headersSent) sendJSON(res, 500, { error: err.message || "标题生成失败" });
    }
    return;
  }

  if (req.method === "POST" && pathname === "/api/outlines") {
    if (!currentUser(req)) return sendJSON(res, 401, { error: "请先登录" });
    try {
      await handleOutlines(req, res, await readBody(req));
    } catch (err) {
      if (!res.headersSent) sendJSON(res, 500, { error: err.message || "大纲生成失败" });
    }
    return;
  }

  if (req.method === "POST" && pathname === "/api/generate") {
    if (!currentUser(req)) return sendJSON(res, 401, { error: "请先登录" });
    try {
      const body = await readBody(req);
      await handleGenerate(req, res, body);
    } catch (err) {
      if (!res.headersSent) {
        res.writeHead(500, { "Content-Type": "application/json; charset=utf-8" });
        res.end(JSON.stringify({ error: err.message || "生成失败" }));
      }
    }
    return;
  }

  if (req.method === "POST" && pathname === "/api/persona/analyze") {
    if (!currentUser(req)) return sendJSON(res, 401, { error: "请先登录" });
    try {
      const body = await readBody(req);
      await handlePersonaAnalyze(req, res, body);
    } catch (err) {
      if (!res.headersSent) sendJSON(res, 500, { error: err.message || "分析失败" });
    }
    return;
  }

  if (req.method === "POST" && pathname === "/api/polish") {
    if (!currentUser(req)) return sendJSON(res, 401, { error: "请先登录" });
    try {
      const body = await readBody(req);
      await handlePolish(req, res, body);
    } catch (err) {
      if (!res.headersSent) sendJSON(res, 500, { error: err.message || "润色失败" });
    }
    return;
  }

  if (req.method === "POST" && pathname === "/api/fix") {
    if (!currentUser(req)) return sendJSON(res, 401, { error: "请先登录" });
    try {
      const body = await readBody(req);
      await handleFix(req, res, body);
    } catch (err) {
      if (!res.headersSent) {
        res.writeHead(500, { "Content-Type": "application/json; charset=utf-8" });
        res.end(JSON.stringify({ error: err.message || "重写失败" }));
      }
    }
    return;
  }

  if (req.method === "GET" || req.method === "HEAD") {
    serveStatic(req, res, pathname);
    return;
  }

  res.writeHead(405);
  res.end("Method not allowed");
});

server.listen(PORT, HOST, () => {
  log(`推文帮服务已启动: http://${HOST}:${PORT}`);
  log(`模型: ${MODEL} · 密钥: ${API_KEY ? "已配置" : "未配置"}`);
  if (!API_KEY) log("警告：未找到 DEEPSEEK_API_KEY，生成接口会返回错误。");
});
